Object.defineProperty(Object.prototype, 'formate', {
    value: function(formate) {
      let date = this.toLocaleString('en-US',{hour12:false}).split(" ");
      let time = date[1];
      let mdy = date[0].split('/');
      let t = time.split(":");
      let formater = {
          "MM": parseInt(mdy[0]),
          "DD": parseInt(mdy[1]),
          "YYYY": parseInt(mdy[2]),
          "H": t[0],
          "M": t[1],
          "S": t[2]
      }
      for (key in formater) {
          formate = formate.replace(key, formater[key])
      }
      return formate
    },
    enumerable: false
});