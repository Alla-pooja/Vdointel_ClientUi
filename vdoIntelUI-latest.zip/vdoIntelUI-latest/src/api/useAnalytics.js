import { useState, useEffect } from 'react';
import { getURL } from 'src/utils/config';
import { handleResponse } from 'src/utils/responseHandler';
import axios from '../axios'
// import { format } from 'date-fns';

const useAnlytics = () => {

    const baseURL = '/devices'
    const initalData = {
        getData: true,
        data: [],
        isLoading: true
    }

    const [cameras, seCameras] = useState(initalData)
    const [analyticsMain, setAnalyticsMain] = useState(initalData)
    const [analyticsSub, setAnalyticsSub] = useState(initalData)
    const [analytics, setAnalyticsData] = useState({
        getData: true,
        data: {},
        response: [],
        activeAnalytics: {}
    })
    const [isSaving, setSave] = useState(false)
    const [responeAlert, setResponseAlert] = useState({ isSuccess: false, isOpen: false })

    // const jsonToParam = (data) => {
    //     return Object.keys(data).map(function (k) {
    //         return encodeURIComponent(k) + '=' + encodeURIComponent(data[k])
    //     }).join('&')
    // }

    useEffect(() => {
        getSavedAnalytics ()
    }, [analytics.getData])

    useEffect(() => {       
        getAllCameras()
    }, [cameras.getData])

    useEffect(() => {       
        getAnalyticsMain()
    }, [analyticsMain.getData])

    useEffect(() => {       
        getAnalyticsSub()
    }, [analyticsSub.getData])

    

    const getAllCameras = () => {
        if (cameras.getData) {
            axios({
                method: 'get',
                url: getURL(baseURL),
                validateStatus: (status) => handleResponse(status)
            }).then((response) => {
                if (response.status === 200 || response.status === 201) {               
                    seCameras({
                            getData: false,
                            data: response.data
                        })
                }
            })
        }
    }   
    
    const getAnalyticsMain = () => {
        if (analyticsMain.getData) {
            axios({
                method: 'get',
                url: getURL('analytics-main'),
                validateStatus: (status) => handleResponse(status)
            }).then((response) => {
                let result = analyticsMain.data
                if (response.status === 200 || response.status === 201)   
                    result = manageAnalyticsMain(response.data) 
                setAnalyticsMain({
                    getData: false,
                    isLoading: false,
                    data: result
                })
            })
        }        
    }

    const setAnalytics = (data) => {  
        setSave(true)      
        axios({
            method: 'post',
            url: getURL('/analytics-settings/add'),
            data: data,
            validateStatus: (status) => handleResponse(status)
        }).then((response) => {
            setSave(false)
            let isSuccess = false
            if (response.status === 200 || response.status === 201) {       
                // console.log('success')
                isSuccess = true
                getSavedAnalytics()
                // setAnalyticsMain({
                //         getData: false,
                //         data: manageAnalyticsMain(response.data)
                //     })
            }
            setResponseAlert({ isSuccess, isOpen: true }) 
        })              
    }

    const setValueToKey = (data, id, key, value) => { 
        data[id][key] = value
        return data
    }

    const manageAnalyticsMain = (data) => {
        let final = {}
        for (let x of data)  {
            final[x.Id] = x
            final[x.Id].isActive = 0      
        }
        // console.log('main', final)
        return final
    }


    const getAnalyticsSub = () => {
        if (analyticsSub.getData) {
            axios({
                method: 'get',
                url: getURL('analytics-sub'),
                validateStatus: (status) => handleResponse(status)
            }).then((response) => {
                if (response.status === 200 || response.status === 201) {               
                    setAnalyticsSub({
                        getData: false,
                        data: manageSubData(response.data)
                    })
                }
            })
        }        
    } 


    const manageSubData = (data) => {
        let final = {}
        for (let x of data) {
            final[x.AnalyticId] = (x.AnalyticId in final) ? final[x.AnalyticId] : {}
            final[x.AnalyticId][x.Id] = x
            final[x.AnalyticId][x.Id].isActive = 0
            // x.isActive = false
            // final[x.AnalyticId].push(x)
            // final[x.AnalyticId][final[x.AnalyticId].length-1]['isActive'] = 0
        }
        // console.log('final', final)
        return final
    }

    const getSavedAnalytics = () => {
        if (analytics.getData) {
            axios({
                method: 'get',
                url: getURL('analytics-settings'),
                validateStatus: (status) => handleResponse(status)
            }).then((response) => {
                if (response.status === 200 || response.status === 201) {  
                    const mgdata = manageAnalyticsData(response.data)
                    setAnalyticsData({
                            getData: false,
                            data: mgdata,
                            response: response.data,
                            activeAnalytics: mgdata
                        })
                }
            })
        }
    }


    const manageAnalyticsData = (data) => {
        let final = {}
        for (let x of data) {
            if (!(x.CameraId in final))
                final[x.CameraId] = {
                    main: [],
                    sub: [] 
                }
            if (!(final[x.CameraId]['main'].includes(x.analyticsmainid)))
                final[x.CameraId]['main'].push(x.analyticsmainid)
            if (!(final[x.CameraId]['sub'].includes(x.analyticssubid)))
                final[x.CameraId]['sub'].push(x.analyticssubid)
        }
        return final
    }

    const setActiveAnalytics = (cameras, mainID, subID, status) => {
        // console.log(status)
        let init = {
            main: [],
            sub: []
        }
        let data = {...analytics.activeAnalytics}
        // console.log('data', data)
        for (let x of cameras) {
            // console.log(x.deviceid)
            data[x.deviceid] = !(x.deviceid in analytics.activeAnalytics) ? init : data[x.deviceid]

            if (!(data[x.deviceid]['main'].includes(mainID))) {              
                data[x.deviceid]['main'].push(mainID) 
            } else if (!status) {
                // console.log('getSubActiveLenght', getSubActiveLenght(mainID), mainID)
                if (getSubActiveLenght(mainID) <= 1)
                    data[x.deviceid]['main'].splice(data[x.deviceid]['main'].indexOf(mainID), 1);  
            }   

            if (!(data[x.deviceid]['sub'].includes(subID)) && status) {                
                data[x.deviceid]['sub'].push(subID)                
            } else if (!status) {
                // console.log('splice', subID, subID)
                data[x.deviceid]['sub'].splice(data[x.deviceid]['sub'].indexOf(mainID), 1);
            }
            // console.info('DATA',data)
            setAnalyticsData({...analytics, activeAnalytics: data})
            if (status)
                activeByCameraId(x.deviceid, data)
            else
                inActiveByCameraId(mainID, subID)
        }
        
    }

    // const setAllCamsDisable

    const setAllInactive = () => {
        for (let mainid in analyticsMain.data) {
            analyticsMain.data[mainid].isActive = 0
            if (mainid in analyticsSub.data) {               
                for (let subid in analyticsSub.data[mainid])                   
                    analyticsSub.data[mainid][subid].isActive = 0
            }
        }
        setAnalyticsMain(analyticsMain)
        setAnalyticsSub(analyticsSub)
    }

    const getSubActiveLenght = (mainid) => {
        let count = 0
        if (mainid in analyticsSub.data) {
            for (let subid in analyticsSub.data[mainid])
                count += analyticsSub.data[mainid][subid].isActive
        }
        return count
    } 

    const inActiveByCameraId = (mainid, subid) => {
        if (mainid in analyticsMain.data) { 
            if (getSubActiveLenght(mainid) <=1)
                analyticsMain.data[mainid].isActive = 0            
        }
        if (mainid in analyticsSub.data) {
            if (subid in analyticsSub.data[mainid])                   
                analyticsSub.data[mainid][subid].isActive = 0
        }
        
        setAnalyticsMain(analyticsMain)
        setAnalyticsSub(analyticsSub)        
    }

    const activeByCameraId = (camId, data=null) => {
        const actAnalytics = data ? data : analytics.activeAnalytics
        if (camId in actAnalytics) { 
            // console.log(analytics.activeAnalytics[camId]['main'])
            actAnalytics[camId]['main'].map((mainid) => { 
                analyticsMain.data[mainid].isActive = 1
                if (mainid in analyticsSub.data) {
                    actAnalytics[camId]['sub'].map((subid) => {  
                        if (subid in analyticsSub.data[mainid])                   
                            analyticsSub.data[mainid][subid].isActive = 1
                    })
                }
            })
            // console.log('analyticsSub', analyticsSub)
            setAnalyticsMain(analyticsMain)
            setAnalyticsSub(analyticsSub)
            // console.log('analyticsMain', analyticsMain)
            // console.log('analyticsSub', analyticsSub)
        }
    }

    const isReloadData = (status) => {
        // seData({ ...isGetData: status })
    }
    
    return {
        cameras,
        analyticsMain,
        analyticsSub,
        analytics,
        isSaving,
        responeAlert,
        setResponseAlert,
        setActiveAnalytics,
        activeByCameraId,
        setAllInactive,
        setAnalytics
    }
}

export default useAnlytics