import axios from 'src/axios'
import { getURL, jsonToParam ,jsonToFormData} from 'src/utils/config';
import { handleResponse } from 'src/utils/responseHandler';

const getProtocols = (callback) => {
    axios({
        method: 'get',
        url: `${getURL('/protocols/get-introsion-types')}`,
        validateStatus: (status) => handleResponse(status)
    }).then((response) => callback(response))
}

const setAddProtocol = (body ,callback) => {
    axios({
        method: 'post',
        url: getURL('/protocols/add-introsion-type'),
        data: body,
        validateStatus: (status) => handleResponse(status)
    }).then((response) => callback(response))
}

const getClientInfo = (clientId ,callback) => {
    axios({
        method: 'get',
        url: `${getURL('/protocols/get-introsion-info')}?client_id=${clientId}`,
        validateStatus: (status) => handleResponse(status)
    }).then((response) => callback(response))
}


const setSaveProtocol = (body ,callback) => {
    axios({
        method: 'post',
        url: getURL('/protocols/add-introsion-contacts'),
        data: body,
        validateStatus: (status) => handleResponse(status)
    }).then((response) => callback(response))
}

export { getProtocols , setAddProtocol ,getClientInfo ,setSaveProtocol } 