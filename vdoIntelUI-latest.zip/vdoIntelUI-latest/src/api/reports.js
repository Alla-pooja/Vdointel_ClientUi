import axios from '../axios'
import { getURL, jsonToParam } from 'src/utils/config';
import { handleResponse } from 'src/utils/responseHandler';

const getAllclientMonReport = (month,year,callback) => {
    axios({
        method: 'get',
        url: `${getURL('/monthly-reports/monthly-report')}?month=${month}&year=${year}`,
        validateStatus: (status) => handleResponse(status)
    }).then((response) => callback(response))
}

export { getAllclientMonReport }
