import axios from "../axios"
import { useEffect, useState } from "react"
import { handleResponse } from 'src/utils/responseHandler';


const useCameras = () => {

    const [ camera, setCamera ] = useState({
        data: [],
        isLoading: false
    })

    useEffect(() => {
        getAllCameras()
    }, [])

    const getAllCameras = () => {
        setCamera({...camera, isLoading: true})
        axios({
            method: 'get',
            url: '/devices',
            validateStatus: (status) => handleResponse(status)
        }).then((response) => {
            setCamera({isLoading: false, data: response.data})
        })
    }

    return {
        camera
    }

}

export default useCameras