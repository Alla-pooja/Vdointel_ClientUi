import axios from 'axios';

const instance = axios.create();
// const instance = axios.create({baseURL: process.env.REACT_APP_API_KEY});
const AUTH_TOKEN = `${localStorage.getItem('token_type')} ${localStorage.getItem('access_token')}`
instance.defaults.maxRedirects = 0
instance.defaults.headers.common.Authorization = AUTH_TOKEN;
instance.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';

export default instance