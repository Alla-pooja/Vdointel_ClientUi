import PropTypes from 'prop-types';
// material
import { Paper, Typography } from '@mui/material';

// ----------------------------------------------------------------------



export default function TableLoad({ ...other }) {
  return (
    <Paper {...other}>      
      <Typography variant="body2" align="center">Loading...</Typography>
    </Paper>
  );
}
