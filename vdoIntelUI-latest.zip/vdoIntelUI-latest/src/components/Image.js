import { useEffect } from "react"

export default function Image ({ src, alt="" }) {

    const [source, setSource] = useState('loding')

    useEffect(() => {
        if (src) {
            fetch(new Request(src), {
                method: 'GET',
                // cache: "no-store",
            }).then((response) => {
                if (Number(response.status) === 200) {
                    setSource(src)
                } else {
                    setSource('404')
                }
            }).catch((error) => {
                setSource('404')
            });  
        } else {
            setSource('404')
        }
    }, [src])

    return (
        <>
        <img src={source} alt={alt} />
        </>
    )

}