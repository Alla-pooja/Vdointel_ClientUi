// component
import Iconify from '../../components/Iconify';

// ----------------------------------------------------------------------

const getIcon = (name) => <Iconify icon={name} width={22} height={22} />;

const navConfig = [
  {
    title: 'Dashboard',
    path: '/',
    icon: getIcon('eva:pie-chart-2-fill'),
    isHideInXs: false,
    positiveAccess: [],
    positiveUserRoles: [],
    negativeUserRoles: [],
    negativeAccess: [],
  },
  {
    title: 'Cameras',
    path: '/cameras',
    icon: getIcon('eva:camera-outline'),
    isHideInXs: false,
    positiveAccess: [],
    positiveUserRoles: [],
    negativeUserRoles: [30, 33, 34, 35],
    negativeAccess: [],
  },
  
  // {
  //   title: 'Notifications',
  //   path: '/notifications',
  //   icon: getIcon('eva:bell-outline'),
  // isHideInXs: false
  // },

  {
    title: 'Audits',
    path: '/audits',
    icon: getIcon('eva:clipboard-outline'),
    isHideInXs: false,
    positiveAccess: [],
    positiveUserRoles: [],
    negativeUserRoles: [30],
    negativeAccess: [],
  },
  // {
  //   title: 'Live Audits',
  //   path: 'live-audits',
  //   icon: getIcon('eva:shake-outline'),
  //   isHideInXs: true,
  //   positiveAccess: [],
  //   positiveUserRoles: [],
  //   negativeUserRoles: [],
  //   negativeAccess: [733, 790],
  // },  
  {
    title: 'Security Reports',
    path: 'reports',
    icon: getIcon('eva:book-outline'),
    isHideInXs: true,
    positiveAccess: [733],
    positiveUserRoles: [],
    negativeUserRoles: [],
    negativeAccess: [],
  },
  {
    title: 'Events Report',
    path: 'jfw-reports',
    icon: getIcon('eva:book-outline'),
    isHideInXs: true,
    positiveAccess: [790],
    positiveUserRoles: [],
    negativeUserRoles: [],
    negativeAccess: [],
  },
  {
    title: 'Head Count Inputs',
    path: 'head-count-input',
    icon: getIcon('eva:book-outline'),
    isHideInXs: true,
    positiveAccess: [797],
    positiveUserRoles: [30, 2, 7],
    negativeUserRoles: [],
    negativeAccess: [],
  },
  {
    title: 'License Plates',
    path: 'license-plate',
    icon: getIcon('eva:car-outline'),
    isHideInXs: true,
    positiveAccess: [692],
    positiveUserRoles: [],
    negativeUserRoles: [],
    negativeAccess: []
  },
  {
    title: 'Head Count Report',
    path: 'head-count-report',
    icon: getIcon('eva:funnel-outline'),
    isHideInXs: true,
    positiveAccess: [797],
    positiveUserRoles: [30, 2, 7],
    negativeUserRoles: [],
    negativeAccess: []
  },
  {
    title: 'Shift Timings',
    path: 'shifttime',
    icon: getIcon('eva:people-outline'),
    isHideInXs: true,
    positiveAccess: [768],
    positiveUserRoles: [],
    negativeUserRoles: [],
    negativeAccess: [],
  },
  {
    title: 'Reports',
    path: '/neterwala',
    icon: getIcon('eva:people-outline'),
    isHideInXs: false,
    positiveAccess: [765],
    positiveUserRoles: [],
    negativeUserRoles: [],
    negativeAccess: [],
  },
  {
    title: 'Live',
    path: '/cameras-live',
    icon: getIcon('eva:video-outline'),
    isHideInXs: false,
    positiveAccess: [],
    positiveUserRoles: [],
    negativeUserRoles: [9],
    negativeAccess: [],
  },
  {
    title: 'Escalated Events',
    path: '/Escalated-Events',
    icon: getIcon('eva:video-off-outline'),
    isHideInXs: false,
    positiveAccess: [],
    positiveUserRoles: [],
    negativeUserRoles: [9],
    negativeAccess: [],
  }
];

export default navConfig;
