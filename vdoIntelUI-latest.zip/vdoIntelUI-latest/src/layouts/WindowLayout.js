import { Outlet } from 'react-router-dom';

export default function WindowLayout() {
  return (
    <>
      <Outlet />
    </>
  );
}
