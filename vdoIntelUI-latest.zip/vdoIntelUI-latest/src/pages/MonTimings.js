import { useState } from 'react';
// material
import {
  Card,
  Stack,
  Container,
  Typography,
  Autocomplete,
  TextField,
  Button,
  Box,
  Divider,
  Alert,
  Snackbar,
  CardContent,
  Grid,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  DialogContentText
} from '@mui/material';
// components
import Page from '../components/Page';
import useAnlytics from 'src/api/useAnalytics';
import { SubAnalyticsDialogBox } from 'src/sections/analytics';
import { LoadingButton } from '@mui/lab';
import Iconify from 'src/components/Iconify';


// import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
// import { LocalizationProvider, TimePicker } from '@mui/x-date-pickers';
// import { TimePicker } from '@mui/x-date-pickers/TimePicker';


const label = { inputProps: { 'aria-label': 'Color switch demo' } };
const cc =['primary', 'secondary', 'info', 'success', 'warning']

export default function MonTimings() {

  const { 
    cameras,
    analyticsMain,
    analyticsSub,
    analytics,
    isSaving,
    responeAlert,
    setResponseAlert,
    setActiveAnalytics,
    activeByCameraId,
    setAllInactive,
    setAnalytics
   } = useAnlytics()

  //  console.log(analytics)

  const [main, setOpen] = useState({
    open: false,
    activeColoum: [],
    AnalyticName: '',
    activeCamIds: []
  });

  const [settingAlert, setSettingAlert] = useState(false)
  const [value, setValue] = useState(null);


  const handleClose = () => {
    setOpen({...main, open: false});
  };

  const handleOpen = () => {
    setOpen({...main, open: true});
  };

  const handleCameras = (event, value) => {
    // console.log(value)
    setSettingAlert(false)
    setAllInactive()
    for (let cam of value)
      activeByCameraId(cam.deviceid)
    setOpen({...main, activeCamIds: value});
  }



  const getActiveAnalyticsById = (cams) => {
    let data = []
    cams.map((camera)=> {
      // console.log(camera)
      if (camera in analytics.activeAnalytics) {
        if ('sub' in analytics.activeAnalytics[camera]) {
          // console.log(analytics.activeAnalytics[camera])
          // console.log(analytics.activeAnalytics[camera]['sub'])
          data = [...data, ...analytics.activeAnalytics[camera]['sub']]
        }        
      }
    })
    return data
  }

  const saveData = () => {
    // main.activeCamIds
    const actCamIDs = [...main.activeCamIds.map((item) => item.deviceid)]
    if (actCamIDs.length > 0) {
      const body = {
        "CameraId": actCamIDs.toString(),
        "AnalyticsSubId": [...getActiveAnalyticsById(actCamIDs)].toString()
      }
      setAnalytics(body)
      // console.log(body)
    } else
      setSettingAlert(true) 
  }

  const resetData = () => {
    
    const actCamIDs = [...main.activeCamIds.map((item) => item.deviceid)]
    if (actCamIDs.length > 0) {
      setAllInactive()
      const body = {
            "CameraId": actCamIDs.toString(),
            "AnalyticsSubId": ""
          }
      // console.log(body)
    } else
        setSettingAlert(true) 
    
  }

  // console.log('analyticsMain', analyticsMain.data)
  // console.log('analyticsSub', analyticsSub.data)
  // console.log('analytics', analytics.data)

  



  return (
    <Page title="Monitoring Times">
      <Container>
        <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>
          <Typography variant="h4" gutterBottom>Monitoring Times</Typography>          
        </Stack>
        <Card sx={{ padding: 3}}>
          <Stack spacing={3} sx={{ maxWidth: 500 }}>
            <Autocomplete
                multiple
                id="tags-outlined"
                options={cameras.data}
                getOptionLabel={(option) => `${option.deviceid} ${option.devicename}`}
                onChange={handleCameras}
                // defaultValue={main.activeCamIds}
                filterSelectedOptions
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Select Camera"
                    placeholder="Search Camera ID or Name..."
                  />
                )}
              />
          </Stack>



          <Box sx={{ paddingTop:2, paddingBottom:2 }}>
            <Grid container spacing={3}>
            {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map((value, key) => 
              (
                
                  <Grid item xs={12} sm={6} md={3} key={key}>
                  <Card 
                  key={key}
                  sx={{
                    py: 2,
                    boxShadow: 0,
                    textAlign: 'center',  
                    color: (theme) => theme.palette[cc[key] || 'primary'].darker,
                    bgcolor: (theme) => theme.palette[cc[key] || 'primary'].lighter,
                
                    
                  }}
                >
                  <CardContent>
                    <Typography variant="h6" component="div">
                    {value}
                    </Typography>
                    <Typography variant="span">10:00 AM to 12:00 PM</Typography>
                    <Iconify onClick={handleOpen} sx={{fontSize: 20, ml:1}} icon="ant-design:edit-outlined" />
                  </CardContent>    
                </Card>
                  </Grid>
                
                
              )
            )}
                </Grid>   
          </Box>

          <Divider />
              {responeAlert.isOpen && (
                <Stack direction="row" sx={{ paddingTop: 2 }}>
                  <Alert onClose={() => setResponseAlert({...responeAlert, isOpen: false})} severity="success">Setup Completed!</Alert>
                </Stack> 
              )}
                   
          <Stack direction="row" spacing={1} sx={{ paddingTop: 2 }}>

            {/* <Button variant="contained" color="error" onClick={resetData}>Reset</Button> */}
            <LoadingButton loading={isSaving} variant="contained" onClick={saveData} >Save Changes</LoadingButton>
        </Stack>


        </Card>



        <Dialog open={main.open} onClose={handleClose}>
        <DialogTitle>Set Timings</DialogTitle>
        <DialogContent>          
          <TextField
            autoFocus
            margin="dense"
            id="name"
            label="From Time"
            type="time"
            fullWidth
            // variant="standard"
          />

<TextField
            autoFocus
            margin="dense"
            id="name"
            label="To Time"
            type="time"
            fullWidth
            // variant="standard"
          />


{/* <LocalizationProvider dateAdapter={AdapterDayjs}>
      <TimePicker
        label="Basic example"
        value={value}
        onChange={(newValue) => {
          setValue(newValue);
        }}
        renderInput={(params) => <TextField {...params} />}
      />
    </LocalizationProvider> */}






        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleClose}>Save</Button>
        </DialogActions>
      </Dialog>


        <Snackbar open={settingAlert} autoHideDuration={1000} >
            <Alert severity="error" sx={{ width: "100%" }}>Please select atleast one device!</Alert>
        </Snackbar>





      </Container>
    </Page>
  );
}
