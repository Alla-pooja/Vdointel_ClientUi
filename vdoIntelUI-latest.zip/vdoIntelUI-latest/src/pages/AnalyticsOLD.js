import { useState } from 'react';
// material
import {
  Card,
  Stack,
  Container,
  Typography,
  Autocomplete,
  TextField,
  Button,
  Box,
  // Divider,
  Alert,
  Snackbar,
  Skeleton,
  Grid,
  styled
} from '@mui/material';
// components
import Page from '../components/Page';
import useAnlytics from 'src/api/useAnalytics';
import { SubAnalyticsDialogBox } from 'src/sections/analytics';
import { LoadingButton } from '@mui/lab';
import Iconify from 'src/components/Iconify';


const AnalyticsMainBox = styled(Card)(() => ({
  border: '1px solid rgba(145, 158, 171, 0.24)',
  boxShadow: 'none'
}))

const AnalyticsMediaBox = styled(Card)(({theme}) => ({
  boxShadow: 'none',
  textAlign: "center", 
  padding: theme.spacing(1.5),
  width: 60,
  height: 60,
}))

export default function Analytics() {

  const { 
    cameras,
    analyticsMain,
    analyticsSub,
    analytics,
    isSaving,
    responeAlert,
    setResponseAlert,
    setActiveAnalytics,
    activeByCameraId,
    setAllInactive,
    setAnalytics
   } = useAnlytics()

  //  console.log(analytics)

  const [main, setOpen] = useState({
    open: false,
    AnalyticName: '',
    activeCamIds: [],
    activeMainId: null  
  });

  const [settingAlert, setSettingAlert] = useState(false)

  const handleClickOpen = (Id, AnalyticName) => {
    setOpen({...main, open: true, AnalyticName: AnalyticName, activeMainId: Id});
  };

  const handleClose = () => {
    setOpen({...main, open: false});
  };

  const handleCameras = (_, value) => {
    // console.log(value)
    setSettingAlert(false)
    setAllInactive()
    for (let cam of value)
      activeByCameraId(cam.deviceid)
    setOpen({...main, activeCamIds: value});
  }

  const checkAnalytics = (type, analyticId) => { 
    // console.log(type, analyticId)      
    for (let x of main.activeCamIds) {
      if (x.CameraId in analytics.activeAnalytics) {
        if (analytics.activeAnalytics[type].includes(analyticId))
          return true
      }
    }
    return false
  }

  const getActiveAnalyticsById = (cams) => {
    let data = []
    cams.map((camera)=> {
      // console.log(camera)
      if (camera in analytics.activeAnalytics) {
        if ('sub' in analytics.activeAnalytics[camera]) {
          // console.log(analytics.activeAnalytics[camera])
          // console.log(analytics.activeAnalytics[camera]['sub'])
          data = [...data, ...analytics.activeAnalytics[camera]['sub']]
        }        
      }
      return camera
    })
    return [...new Set(data)]
  }

  const saveData = () => {
    // main.activeCamIds
    const actCamIDs = [...main.activeCamIds.map((item) => item.deviceid)]
    if (actCamIDs.length > 0) {
      const body = {
        "CameraId": actCamIDs.toString(),
        "AnalyticsSubId": [...getActiveAnalyticsById(actCamIDs)].toString()
      }
      setAnalytics(body)
      // console.log(body)
    } else
      setSettingAlert(true) 
  }

  const resetData = () => {
    
    const actCamIDs = [...analytics.response.map((item) => item.CameraId)]
    if (actCamIDs.length > 0) {
      setAllInactive()
      const body = {
            "CameraId": actCamIDs.toString(),
            "AnalyticsSubId": ""
          }
      setAnalytics(body)
      // console.log(body)
    } else
        setSettingAlert(true) 
    
  }

  // console.log('analyticsMain', analyticsMain.data)
  // console.log('analyticsSub', analyticsSub.data)
  // console.log('analytics', analytics.activeAnalytics)

  



  return (
    <Page title="Analytics">
      <Container  maxWidth="xl">
        <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>
          <Typography variant="h4" gutterBottom>Analytics</Typography>          
        </Stack>

        {/* <Grid container spacing={2} sx={{ pt: 2, pb: 5 }}>
            <Grid item md={2}>
                <AnalyticsMainBox sx={{ p: 2 }}>                  
                  <Typography variant="h5">Analytics</Typography>   
                  <Typography color={'gray'} sx={{pt:1, pb: 2}}>No problem, I'm glad to hear that the solution worked for you!</Typography>   
                  <AnalyticsMediaBox sx={{
                      color: (theme) => theme.palette['primary'].darker,
                      bgcolor: (theme) => theme.palette['primary'].lighter}}>
                    <Iconify icon={'mdi:head-snowflake-outline'} width={40} height={40} />
                  </AnalyticsMediaBox>                  
                </AnalyticsMainBox>
            </Grid>
        </Grid> */}


        {/* <Card sx={{ padding: 3}}> */}
          <Stack spacing={3} sx={{ maxWidth: 500 }}>
            <Autocomplete
                multiple
                id="tags-outlined"
                options={cameras.data}
                getOptionLabel={(option) => `${option.deviceid} ${option.devicename}`}
                onChange={handleCameras}
                // defaultValue={main.activeCamIds}
                filterSelectedOptions 
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Select Camera"
                    placeholder="Search Camera ID Or Name..."
                  />
                )}
              />
          </Stack>
          
          {!analyticsMain.isLoading ? (
            <Grid container spacing={2} sx={{ pt: 2 }}>
                {Object.values(analyticsMain.data).map((row, key) => (  



                  <Grid item md={2} key={key}>
                    <AnalyticsMainBox sx={{ p: 2 }} onClick={() => handleClickOpen(row.Id, row.DisplayName)}>                  
                    <AnalyticsMediaBox sx={{
                          color: (theme) => theme.palette[row.isActive ? 'success': 'primary'].darker,
                          // bgcolor: (theme) => theme.palette[row.isActive ? 'success': 'primary'].lighter
                          }}>
                        <Iconify icon={row.Icon || 'mdi:head-snowflake-outline'} width={35} height={35} />
                      </AnalyticsMediaBox>     
                      <Typography sx={{ pt:2 }} variant="h5">{row.DisplayName}</Typography>   
                      <Typography color={'gray'} sx={{pt:1}}>Small description about analytics.</Typography>   
                                   
                    </AnalyticsMainBox>
                  </Grid>


                  // <Grid item md={1.5} key={key}>     
                  //   <Button sx={{ width: "100%", p: 2 }} color={row.isActive ? 'success': 'primary'} variant="outlined" onClick={() => handleClickOpen(row.Id, row.AnalyticName)}  >
                  //     <Box>
                  //       <Iconify icon={row.Icon || 'mdi:head-snowflake-outline'} width={35} height={35} />
                  //       <Typography>{row.DisplayName}</Typography>
                  //     </Box>
                  //   </Button>
                  // </Grid>
                ))}        
            </Grid> 
          ): (
            <Stack direction="row" sx={{ paddingTop:2, paddingBottom:2 }}>
              {[...Array(5)].map((_, key) => (
                
                <Box key={key} sx={{ width:"20%" }}>
                    <Skeleton sx={{mr:1, mb:1}}  variant="rounded" height={40} />           
                    <Skeleton sx={{mr:1, mb:1}} variant="rounded" height={40} />           
                    {/* <Skeleton sx={{mt:0.5}} variant="rounded" height={50} /> */}
                </Box>
              ))}
            </Stack>
          )}
          
          
         
          <SubAnalyticsDialogBox analyticsSub={analyticsSub} main={main} handleClose={() => handleClose()} checkAnalytics={checkAnalytics} setActiveAnalytics={setActiveAnalytics}/>
   
          {/* <Divider /> */}
              {responeAlert.isOpen && (
                <Stack direction="row" sx={{ paddingTop: 2 }}>
                  <Alert onClose={() => setResponseAlert({...responeAlert, isOpen: false})} severity="success">Setup Completed!</Alert>
                </Stack> 
              )}
                   
          <Stack direction="row" spacing={1} sx={{ paddingTop: 2 }}>

            <Button variant="contained" color="error" onClick={resetData}>Reset</Button>
            <LoadingButton loading={isSaving} variant="contained" onClick={saveData} >Save</LoadingButton>
        </Stack>


        {/* </Card> */}

        <Snackbar open={settingAlert} autoHideDuration={1000} >
            <Alert severity="error" sx={{ width: "100%" }}>Please select atleast one device!</Alert>
        </Snackbar>

      </Container>
    </Page>
  );
}
