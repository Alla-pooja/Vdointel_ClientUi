import {  Container, Typography } from '@mui/material';
// components
import Page from '../components/Page';


// ----------------------------------------------------------------------



export default function BlankPage() {

  return (
    <Page title="Dashboard">
      <Container maxWidth="xl">
        

        
      </Container>
    </Page>
  );
}
