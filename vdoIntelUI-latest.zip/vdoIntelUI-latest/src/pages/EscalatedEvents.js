import React, { useState } from 'react';
import {
  Grid,
  Button,
  Typography,
  Container,
  Card,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Autocomplete,
  TextField
} from '@mui/material';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { renderTimeViewClock } from '@mui/x-date-pickers/timeViewRenderers';
import Page from '../components/Page';

export default function EscalatedEvents() {
  const [tableData, setTableData] = useState([]);

  const handleSubmit = () => {
    // Fetch data and update tableData state
    // Example:
    const newData = [
      {
        id: 1,
        preview: 'Preview',
        cameraName: 'Camera Name',
        eventNo: 'Event No',
        eventType: 'Event Type',
        eventTime: 'Event Time',
        priority: 'Priority',
        announcement: 'Announcement',
        notes: 'Notes',
      },
      // Add more data as needed
    ];
    setTableData(newData);
  };

  return (
    <Page title="Live">
      <Container maxWidth="xl" style={{ width: '100%', height: '30px' }}>
        <Card style={{ width: '100%', height: '110px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Grid container spacing={2} alignItems="center" style={{ marginLeft: '10px', marginRight: '10px' }}>
            <Grid item xs={2}>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DateTimePicker
                    label = 'From Date'
                  viewRenderers={{
                    hours: renderTimeViewClock,
                    minutes: renderTimeViewClock,
                    seconds: renderTimeViewClock,
                  }}
                  format="YYYY-MM-DD HH:mm"
                />
              </LocalizationProvider>
            </Grid>
            <Grid item xs={2}>

              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DateTimePicker
                  label = 'To Date'
                  viewRenderers={{
                    hours: renderTimeViewClock,
                    minutes: renderTimeViewClock,
                    seconds: renderTimeViewClock,
                  }}
                  format="YYYY-MM-DD HH:mm"
                />
              </LocalizationProvider>

            </Grid>
            <Grid item xs={2}>

                    <Autocomplete
                    multiple
                    id="tags-outlined-client"
                    options="{client}"
                    getOptionLabel="{(option) => `${option.Name}`}"
                    onChange="{handleClient}"
                    renderInput={(params) => (
                        <TextField
                        {...params}
                        label="Select Client"
                        placeholder="Search Client Name..."
                        />
                    )}
                    />

            </Grid>
            <Grid item xs={2}>
              <Button variant="contained" onClick={handleSubmit}>
                Submit
              </Button>
            </Grid>

          </Grid>

        </Card>
      </Container>
      {tableData.length > 0 && (
        <Container maxWidth="xl" style={{ marginTop: '100px' }}>
          <Card>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>S.No</TableCell>
                    <TableCell>Preview</TableCell>
                    <TableCell>Camera Name</TableCell>
                    <TableCell>Event No</TableCell>
                    <TableCell>Event Type</TableCell>
                    <TableCell>Event Time</TableCell>
                    <TableCell>Priority</TableCell>
                    <TableCell>Announcement</TableCell>
                    <TableCell>Notes</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {tableData.map((row) => (
                    <TableRow key={row.id}>
                      <TableCell>{row.id}</TableCell>
                      <TableCell>{row.preview}</TableCell>
                      <TableCell>{row.cameraName}</TableCell>
                      <TableCell>{row.eventNo}</TableCell>
                      <TableCell>{row.eventType}</TableCell>
                      <TableCell>{row.eventTime}</TableCell>
                      <TableCell>{row.priority}</TableCell>
                      <TableCell>{row.announcement}</TableCell>
                      <TableCell>{row.notes}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Card>
        </Container>
      )}
    </Page>
  );
}
