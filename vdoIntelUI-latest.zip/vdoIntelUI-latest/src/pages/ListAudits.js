import {
  Container,
  Stack,
  Typography,
  CircularProgress,
  OutlinedInput,
  InputAdornment,
  Toolbar,
  Box,
  Card,
  Autocomplete,
  TextField,
  Chip,
  Button,
} from '@mui/material';
// components
import Page from '../components/Page';
import { AuditList } from '../sections/auditlist';
// mock
import { styled } from '@mui/material/styles';
import useAuditList from 'src/api/useAuditList';
import Iconify from 'src/components/Iconify';

import { LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { format } from 'date-fns';
import DeleteIcon from '@mui/icons-material/Delete';
import NotificationAlert from 'src/utils/NotificationAlert';
// import CloseIcon from '@mui/icons-material/Close';
// import { useState } from 'react';
// ----------------------------------------------------------------------

const SearchStyle = styled(OutlinedInput)(({ theme }) => ({
  maxWidth: 200,
  transition: theme.transitions.create(['box-shadow', 'width'], {
    easing: theme.transitions.easing.easeInOut,
    duration: theme.transitions.duration.shorter,
  }),
  '&.Mui-focused': { width: 320, boxShadow: theme.customShadows.z8 },
  '& fieldset': {
    borderWidth: `1px !important`,
    borderColor: `${theme.palette.grey[500_32]} !important`,
  },
}));

const CustomBox = styled(Stack)(({ theme }) => ({
  border: `1px dashed rgba(145, 158, 171, 0.16)`,
  padding: theme.spacing(1),
  borderRadius: 8
}));

const RootStyle = styled(Toolbar)(({ theme }) => ({
  height: 96,
  display: 'flex',
  justifyContent: 'space-between',
  // padding: theme.spacing(0, 1, 0, 3),
}));

export default function ListAudits({userType, clientId}) {
  const {
    alldata,
    setSearch,
    loadMoreAudits,
    filterAudits,
    updateToClient,
    isEscalating,
    open,
    setOpen,
    cameras,
    analytics,
    fromDate,
    toDate,
    handleFromDate,
    handleToDate,
    detectedType,
    handleDetectedType,
    device,
    handleDevice,
    handleDelete,
    handlerGetFilterData,
    alertStatus,
    handleNotificationBar
  } = useAuditList(userType)

  // console.log(alldata)



  const onFilterAudits = (event) => {
    setSearch(event.target.value)
    filterAudits(event.target.value)
  }

  return (
    <Page title="Audits">
      <Container maxWidth="xl">
        <NotificationAlert 
        open={alertStatus.open}  
        handleClose={handleNotificationBar} 
        title={alertStatus.title} 
        description={alertStatus.description}/>
        {/* <Typography variant="h4" sx={{ mb: 5 }}> Audits </Typography> */}

        {/* <Collapse in={open}>
          <Alert
            severity="error"
            action={
              <IconButton
                aria-label="close"
                color="inherit"
                size="small"
                onClick={() => setOpen(false)}
              > */}
        {/* <CloseIcon fontSize="inherit" /> */}
        {/* </IconButton>
            }
            sx={{ mb: 2 }}
          >
            New Audit Alert!
          </Alert>
        </Collapse> */}

        <Typography variant="h4">Audits </Typography>
        {Number(userType) === 33 && (
          <Typography sx={{ fontWeight: 800 }}>Note: Monitoring hours - 10 PM to 6 AM</Typography>
        )}        
        
        <Card sx={{ mt: 2}}>


          <Stack direction="row" spacing={2} sx={{ p: 2 }}>


            <LocalizationProvider  dateAdapter={AdapterDayjs}>
              <DatePicker sx={{width: "100%"}} label="From Date" value={fromDate} onChange={handleFromDate} />
            </LocalizationProvider>

            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker sx={{width: "100%"}} label="To Date" value={toDate} onChange={handleToDate} />
            </LocalizationProvider>


            <Autocomplete
              fullWidth
              // sx={{ minWidth: 300 }}
              multiple
              id="detected-types"
              options={analytics}
              getOptionLabel={(option) => option.Name}
              value={detectedType}
              onChange={handleDetectedType}
              renderOption={(props, option) => (
                <Box component="li" {...props} key={option.Name}>
                  {option.Name}
                </Box>
              )}
              filterSelectedOptions
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Detected Types"
                  placeholder="Detected Types"
                />
              )}
            />            

            <Autocomplete
              fullWidth
              multiple
              id="cameras"
              // sx={{ minWidth: 300 }}
              options={cameras}
              getOptionLabel={(option) => option.devicename}
              filterSelectedOptions
              value={device}
              onChange={handleDevice}
              renderOption={(props, option) => (
                <Box component="li" {...props} key={option.uid}>
                  {option.devicename}
                </Box>
              )}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Cameras"
                  placeholder="Cameras"
                />
              )}
            />
            <Box sx={{ display: "flex", alignItems: "center" }}>
              <Button disabled={!(fromDate || toDate || detectedType.length > 0 || device.length > 0)} onClick={handlerGetFilterData} variant='contained' size="large">Get</Button>
            </Box>
            {/* {((fromDate && toDate) || detectedType.length > 0 || device.length > 0) && (
              <Box sx={{ display: "flex", alignItems: "center" }}>
                <Button color="error" onClick={() => handleDelete('clear')} startIcon={<DeleteIcon />}>Clear</Button>
              </Box>
            )} */}
            
            
            
            
            {/* <AuditListFilterSidebar
              isOpenFilter={openFilter}
              onOpenFilter={handleOpenFilter}
              onCloseFilter={handleCloseFilter}
            /> */}
          </Stack>

          {(fromDate || toDate || detectedType.length > 0 || device.length > 0) && (
            <Stack
              direction="row"
              justifyContent="flex-start"
              alignItems="flex-start"
              spacing={2}
              sx={{ px: 2, pb: 2 }}
            >


              {fromDate && (
                <CustomBox
                  direction="row"
                  justifyContent="flex-start"
                  alignItems="flex-start"
                  spacing={2}
                >
                  <Typography variant='subtitle2'>From Date:</Typography>
                  <Chip
                    color="primary"
                    label={`${format(new Date(fromDate), 'dd-MM-yyyy')}`}
                    sx={{ backgroundColor: '#212b36' }}
                    size="small"
                    onDelete={() => handleDelete('fromDate')} />
                </CustomBox>
              )}

              {toDate && (
                <CustomBox
                  direction="row"
                  justifyContent="flex-start"
                  alignItems="flex-start"
                  spacing={2}
                >
                  <Typography variant='subtitle2'>To Date:</Typography>
                  <Chip
                    color="primary"
                    label={`${format(new Date(toDate), 'dd-MM-yyyy')}`}
                    sx={{ backgroundColor: '#212b36' }}
                    size="small"
                    onDelete={() => handleDelete('toDate')} />
                </CustomBox>
                )}


              {detectedType.length > 0 && (
                <CustomBox
                  direction="row"
                  justifyContent="flex-start"
                  alignItems="flex-start"
                  spacing={2}
                >
                  <Typography variant='subtitle2'>Detected Types:</Typography>
                  {detectedType.map((dType, index) => (
                    <Chip
                      key={index}
                      color="primary"
                      label={dType.Name}
                      sx={{ backgroundColor: '#212b36' }}
                      size="small"
                      onDelete={() => handleDelete('detectedType', index)} />
                  ))}
                </CustomBox>
              )}


              {device.length > 0 && (
                <CustomBox
                  direction="row"
                  justifyContent="flex-start"
                  alignItems="flex-start"
                  spacing={2}
                >
                  <Typography variant='subtitle2'>Cameras:</Typography>
                  {device.map((item, index) => (
                    <Chip
                      key={index}
                      color="primary"
                      label={item.devicename}
                      sx={{ backgroundColor: '#212b36' }}
                      size="small"
                      onDelete={() => handleDelete('camera', index)} />
                  ))}
                </CustomBox>
              )}         

                <Box sx={{ display: "flex", alignItems: "center" }}>
                <Button color="error" onClick={() => handleDelete('clear')} startIcon={<DeleteIcon />}>Clear</Button>
              </Box>


            </Stack>
          )}



            <Box sx={{ backgroundColor: "#ebebeb", p: 1 }}>
              <Box sx={{ textAlign: "right" }}>
                  <SearchStyle
                    // value={filterAudit}
                    onChange={onFilterAudits}
                    sx={{ backgroundColor: "white", mb: 1 }}
                    placeholder="Search..."
                    startAdornment={
                      <InputAdornment position="start">
                        <Iconify icon="eva:search-fill" sx={{ color: 'text.disabled', width: 20, height: 20 }} />
                      </InputAdornment>
                    }
                  />
              </Box>

            {(alldata.isLoad) && (
              <Box sx={{display: "flex",
                alignItems: "center"}}>
                <CircularProgress sx={{ marginLeft: '45%' }} />
              </Box>
            )}            
            <AuditList audits={alldata.filterData} loadMoreAudits={loadMoreAudits} updateToClient={updateToClient} isEscalating={isEscalating} />
          </Box>

        </Card>
      </Container>
    </Page>
  );
}
