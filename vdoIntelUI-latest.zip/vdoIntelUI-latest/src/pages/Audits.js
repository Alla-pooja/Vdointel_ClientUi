import { filter } from 'lodash';
import { useEffect, useState } from 'react';
// material
import {
  Card,
  Table,
  Stack,
  TableRow,
  TableBody,
  TableCell,
  Container,
  Typography,
  TableContainer,
  TablePagination,
  IconButton
} from '@mui/material';
// components
import Page from '../components/Page';
import Scrollbar from '../components/Scrollbar';
import Iconify from '../components/Iconify';
import SearchNotFound from '../components/SearchNotFound';
import TableLoad from '../components/TableLoad';

import { UserListHead, UserListToolbar, AuditPlayer } from '../sections/@dashboard/audit';
// mock
// import USERLIST from '../_mock/user';
import axios from '../axios'
import { handleResponse } from 'src/utils/responseHandler';

// ----------------------------------------------------------------------
// console.log(USERLIST)

const TABLE_HEAD = [
  { id: 'Id', label: 'S.No', alignRight: false },
  { id: 'VideoUrl', label: 'Video', alignRight: false },
  { id: 'DeviceName', label: 'Camera Name', alignRight: false },
  { id: 'DetectedType', label: 'Detected Type', alignRight: false },  
  { id: 'Remarks', label: 'Remarks', alignRight: false },
  { id: 'CreatedOn', label: 'Event Time', alignRight: false }
  // { id: '' },
];

// ----------------------------------------------------------------------

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  if (query) {
    return filter(array, (_user) => _user.AnalyticsId.toLowerCase().indexOf(query.toLowerCase()) !== -1);
  }
  return stabilizedThis.map((el) => el[0]);
}

export default function User() {
  const [page, setPage] = useState(0);

  const [order, setOrder] = useState('asc');

  const [orderBy, setOrderBy] = useState('name');

  const [filterName, setFilterName] = useState('');

  const [rowsPerPage, setRowsPerPage] = useState(10);

  const [auditslist, setAuditList] = useState([])

  const initValues = {
      src: null,
      isOpen: false
  }
  const [player, setPlayer] = useState(initValues)
  const [isLoad, setLoadStatus] = useState(true)

  useEffect(() => {
    setLoadStatus(true)
    axios({
      method: 'get',
      url: '/clientaudits',
      validateStatus: (status) => handleResponse(status)
    }).then(function (response) {
      setLoadStatus(false)
      if (response.status === 200 || response.status === 201) {
        setAuditList(() => response.data)
      }
      
    })
  }, [setAuditList])

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleFilterByName = (event) => {
    setFilterName(event.target.value);
  };

  const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - auditslist.length) : 0;

  const filteredUsers = applySortFilter(auditslist, getComparator(order, orderBy), filterName);

  const isUserNotFound = filteredUsers.length === 0;

  function handleDialog (src) {
    const isOpen = true    
    setPlayer ((plyr) => { return {...AuditPlayer, isOpen, src}})
  }

  

  return (
    <Page title="User">
      <Container>
        <AuditPlayer player={player} setPlayer={setPlayer}/>
        <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>
          <Typography variant="h4" gutterBottom>
            Audits
          </Typography>          
        </Stack>

        <Card>
          <UserListToolbar  filterName={filterName} onFilterName={handleFilterByName} />

          <Scrollbar>
            <TableContainer sx={{ minWidth: 800 }}>
              <Table>
                <UserListHead
                  order={order}
                  orderBy={orderBy}
                  headLabel={TABLE_HEAD}
                  rowCount={auditslist.length}
                  onRequestSort={handleRequestSort}
                  // onSelectAllClick={handleSelectAllClick}
                />
                <TableBody>
                  {filteredUsers.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
                    const { Id, VideoUrl, DeviceName, DetectedType, Remarks, CreatedOn } = row;

                    return (
                      <TableRow
                        hover
                        key={Id}
                        tabIndex={-1}
                        role="checkbox"
                      >
                        {/* <TableCell padding="checkbox">
                          <Checkbox checked={isItemSelected} onChange={(event) => handleClick(event, CreatedOn)} />
                        </TableCell> */}
                        <TableCell align="left">{Id}</TableCell>
                        <TableCell align="left">
                          
                            <IconButton onClick={() => handleDialog(VideoUrl)}>
                              <Iconify icon="eva:play-circle-outline" width={20} height={20} />
                            </IconButton>
                            {/* <Typography variant="subtitle2" noWrap>
                              {VideoUrl}
                            </Typography> */}
                        
                        </TableCell>
                        {/* <TableCell align="left">{VideoUrl}</TableCell> */}
                        <TableCell align="left">{DeviceName}</TableCell>
                        <TableCell align="left">{DetectedType}</TableCell>
                        <TableCell align="left">{Remarks}</TableCell>
                        <TableCell align="left">{CreatedOn}</TableCell>
                        {/* <TableCell align="left">
                          <Label variant="ghost" color={(status === 'banned' && 'error') || 'success'}>
                            {sentenceCase(status)}
                          </Label>
                        </TableCell> */}

                        {/* <TableCell align="right">
                          <UserMoreMenu />
                        </TableCell> */}
                      </TableRow>
                    );
                  })}
                  {emptyRows > 0 && (
                    <TableRow style={{ height: 53 * emptyRows }}>
                      <TableCell colSpan={6} />
                    </TableRow>
                  )}
                </TableBody>

                {(isUserNotFound && isLoad === false) && (
                  <TableBody>
                    <TableRow>
                      <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                        <SearchNotFound searchQuery={filterName} />
                      </TableCell>
                    </TableRow>
                  </TableBody>
                )}

                {(isLoad) && (
                  <TableBody>
                    <TableRow>
                      <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                        <TableLoad />
                      </TableCell>
                    </TableRow>
                  </TableBody>
                )}
              </Table>
            </TableContainer>
          </Scrollbar>

          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={auditslist.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Card>
      </Container>
    </Page>
  );
}
