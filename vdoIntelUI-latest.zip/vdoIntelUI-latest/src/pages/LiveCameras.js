import { Button, Card, Container, FormControl, Grid, Box, CardContent, InputLabel, MenuItem, Select, Stack, Typography } from '@mui/material';
import { LoadingButton } from '@mui/lab';
import Page from '../components/Page';
import { useState } from 'react';

export default function LiveCameras() {
  const [selectedGroup, setSelectedGroup] = useState('');
  const [selectedClient, setSelectedClient] = useState('');
  const [selectedCameras, setSelectedCameras] = useState([]);
  const [submitted, setSubmitted] = useState(false);

  const handleGroupChange = (event) => {
    setSelectedGroup(event.target.value);
  };

  const handleClientChange = (event) => {
    setSelectedClient(event.target.value);
  };

  const handleCameraChange = (event) => {
    const selectedCamera = event.target.value;
    setSelectedCameras([...selectedCameras, selectedCamera]);
  };

  const handleSubmit = () => {
    console.log("Selected Group:", selectedGroup);
    console.log("Selected Client:", selectedClient);
    console.log("Selected Cameras:", selectedCameras);
    setSelectedCameras([1,1,1,1,1,1,1,1]);
    setSubmitted(true);
  };

  let gridColumns = selectedCameras.length;

  const gridConfigurations = {
    1: { height: 630, width: '100%' },
    2: { height: 630, width: '100%' },
    3: { height: 315, width: '100%' },
    4: { height: 315, width: '100%' },
    8: { height: 315, width: '100%' }, 
    16: { height: 315, width: '100%' },// Adjusted width for 8 cameras
  };

  return (
    <Page title="Live">
      <Container maxWidth="xl" style={{ width: '100%', height: '30px' }}>
        <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>
          <Typography variant="h4" gutterBottom>Live</Typography>
        </Stack>
        <Card style={{ width: '100%', height: '90px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Grid container spacing={2} alignItems="center" justifyContent="space-between" style={{ marginLeft: '10px', marginRight: '10px' }}>
            <Grid item xs={3}>
              <FormControl fullWidth>
                <InputLabel id="group-label">Group</InputLabel>
                <Select
                  labelId="group-label"
                  value={selectedGroup}
                  onChange={handleGroupChange}
                  label="Group"
                >
                  <MenuItem value="">
                    
                  </MenuItem>
                  <MenuItem value={1}>Group 1</MenuItem>
                  <MenuItem value={2}>Group 2</MenuItem>
                  <MenuItem value={3}>Group 3</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={3}>
              <FormControl fullWidth>
                <InputLabel id="client-label">Select Client</InputLabel>
                <Select
                  labelId="client-label"
                  value={selectedClient}
                  onChange={handleClientChange}
                  label="Select Client"
                >
                  <MenuItem value="">
                    
                  </MenuItem>
                  <MenuItem value={1}>Client 1</MenuItem>
                  <MenuItem value={2}>Client 2</MenuItem>
                  <MenuItem value={3}>Client 3</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={6} container justifyContent="flex-end">
              <Stack direction="row" spacing={1} alignItems="center">
                <LoadingButton variant="contained" color="error">Cancel</LoadingButton>
                <LoadingButton variant="contained" onClick={handleSubmit}>Submit</LoadingButton>
              </Stack>
            </Grid>
          </Grid>
        </Card>
        {submitted && (
          <Grid container spacing={2} mt={3} alignItems="center" justifyContent={gridColumns === 3 ? 'flex-start' : 'center'}>
            {selectedCameras.map((camera, index) => (
              <Grid item xs={gridColumns === 1 ? 12 : 3} key={index}> {/* Adjusted column size for 8 cameras */}
                <Card sx={{ background: "#f0f3f5" }} style={{ height: gridConfigurations[gridColumns].height, width: gridConfigurations[gridColumns].width }}>
                  <Box
                    component="img"
                    sx={{
                      height: gridConfigurations[gridColumns].height - 45, // Adjusting the height considering the card content
                      display: 'block',
                      maxWidth: '100%',
                      overflow: 'hidden',
                      width: '100%',
                      p: 2,
                      borderRadius: 3.5
                    }}
                    src={`https://images.unsplash.com/photo-1538032746644-0212e812a9e7?auto=format&fit=crop&w=400&h=250&q=60`}
                    alt={`Camera ${index}`}
                  />
                  <CardContent sx={{ pt: 1, pb: 0 }}>
                    <Typography variant='h6'>Camera {index + 1}</Typography>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        )}
      </Container>
    </Page>
  );
}
