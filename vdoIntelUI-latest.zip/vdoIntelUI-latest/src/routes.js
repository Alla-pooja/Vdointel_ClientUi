import { Navigate, useRoutes } from 'react-router-dom';
import { useState } from 'react';
// layouts
import DashboardLayout from './layouts/dashboard';
import LogoOnlyLayout from './layouts/LogoOnlyLayout';
import WindowLayout from './layouts/WindowLayout';

//
// import Blog from './pages/Blog';
// import User from './pages/User';
// import Audits from './pages/Audits';
import AuditLive from './pages/AuditLive';
import Live from './pages/Live';
import Login from './pages/Login';
import NotFound from './pages/Page404';
// import Register from './pages/Register';

import ListAudits from './pages/ListAudits';

import DashboardApp from './pages/DashboardApp';
import Analytics from './pages/Analytics';
import Notifications from './pages/Notifications';
import MonTimings from './pages/MonTimings';
import LicenceUpgrade from './pages/LicenceUpgrade';
import Cameras from './pages/Cameras';
import { isAccess } from './utils/responseHandler';
import Clients from './pages/Clients';
import Devices from './pages/Devices';
import LiveCameras from './pages/LiveCameras';
import EmpProductivity from './pages/EmpProductivity';
import Servers from './pages/Servers';
import JKODashboard from './pages/JKODashboard';
import AutoLogin from './pages/AutoLogin';
import Reports from './pages/Reports';
import JFWReport from './pages/JFWReport';
import DevicesReport from './pages/DevicesReport';
import HeadCountReport from './pages/HeadCountReport';
import HeadCountDashboard from './pages/HeadCountDashboard';
import HeadCountInput from './pages/HeadCountInput';
import LicensePlate from './pages/LicensePlate';
import Timelaps from './pages/Timelaps';
import ShiftTme from './pages/ShiftTme';
import NetrawalaEntry from './pages/netrawalaEntry';
// ----------------------------------------------------------------------
import DeploymentReports from './pages/DeploymentReports';
import EscalatedEvents from './pages/EscalatedEvents';
import Groupsdetails from './sections/settings/Groupsdetails';
import Protocols from './sections/settings/protocols';

const userValues = {
    "access_token": localStorage.getItem('access_token'),
    "token_type": localStorage.getItem('token_type'),      
    "ID": localStorage.getItem('ID'),
    "IsLicenseBase": localStorage.getItem('IsLicenseBase'),
    "IsAgentBased": localStorage.getItem('IsAgentBased'),
    "name": localStorage.getItem('name'),
    "displayname": localStorage.getItem('displayname'),
    "logo_url": localStorage.getItem('logo_url'),
    "user_type": localStorage.getItem('user_type'),
    "client_id": localStorage.getItem('client_id')
}



export default function Router() {
  const [token, setToken] = useState(localStorage.getItem('access_token'))  
  const [userType, setUserType] = useState(localStorage.getItem('user_type'))
  const [userData, setuserData] = useState(userValues)
  const [access, setAccess] = useState(isAccess())  
  

  const DASH_LAYOUT = [{
    path: '/',
    element: <DashboardLayout setToken={setToken} userType={userType} userData={userData} />,
    children: [
      { path: '/', element: Number(userData.client_id) === 733 ? <JKODashboard/> :<DashboardApp clientId={userData.client_id} userType={userData.user_type} /> },
      // { path: '/', element: Number(userData.client_id) === 765 ? <NetrawalaEntry/> :<DashboardApp clientId={userData.client_id} userType={userData.user_type} /> },
      { path: 'audits', element: <ListAudits userType={userData.user_type} clientId={userData.client_id}/> },
      // { path: 'products', element: <ListAudits /> },
      { path: 'live-audits', element: <AuditLive /> },
      { path: 'analytics', element: <Analytics userType={9} /> },
      { path: 'mon-timings', element: <MonTimings /> },
      { path: 'cameras', element: <Cameras /> },
      { path: 'cameras-live', element: <LiveCameras /> },
      { path: 'Escalated-Events', element: <EscalatedEvents /> },
      { path: 'clients', element: <Clients /> },
      { path: 'devices', element: <Devices /> },
      { path: 'emp-productivity', element: <EmpProductivity /> },
      { path: 'jfw-reports', element: <JFWReport /> },
      { path: 'servers', element: <Servers /> },
      { path: 'reports', element: <Reports /> },
      { path: 'head-count-report', element: <HeadCountReport /> },
      { path: 'head-count-dashboard', element: <HeadCountDashboard /> },
      { path: 'head-count-input', element: <HeadCountInput /> },
      { path: 'deployment-reports', element: <DeploymentReports /> },
      { path: 'devices-report', element: <DevicesReport /> },
      { path: 'notifications/*', element: <Notifications />},
      { path: 'license-plate', element: <LicensePlate /> },
      { path: 'timelaps', element: <Timelaps /> },
      { path: 'shifttime', element: <ShiftTme /> },
      // { path: 'group-settings', element: <Groups /> },
      { path: 'neterwala', element: <NetrawalaEntry /> },
      { path: 'groups', element: <Groupsdetails/>},
      { path: 'device_protocols', element: <Protocols/>},

      { path: 'auto-login', element: <AutoLogin setToken={setToken} setAccess={setAccess} setUserType={setUserType} setuserData={setuserData} /> },
      // { path: '*', element: <Navigate to={Number(userData.user_type) === 30 ? "/": "/audits"} replace /> },
      // { path: '*', element: <Navigate to={Number(userData.client_id) === 765 ? "/neterwala": "/neterwala"} replace /> }
      {
        path: '*',
        element: <Navigate to={Number(userData.client_id) === 765 ? "/neterwala" : (Number(userData.user_type) === 30 ? "/" : "/audits")} replace />
      }
      
    ]
  },
  {
    path: '/',
    element: <WindowLayout />,
    children: [
      { path: 'audit-live/:gridview', element: <Live/> },
      { path: '404', element: <NotFound /> },
      // { path: 'licence', element: <LicenceUpgrade /> },      
      { path: '*', element: <Navigate to="/404" /> }
    ]
  }
]

  const LOGO_LAYOUT = [{
    path: '/',
    element: <LogoOnlyLayout />,
    children: [
      { path: '/', element: <Navigate to="/login" /> },
      { path: 'auto-login', element: <AutoLogin setToken={setToken} setAccess={setAccess} setUserType={setUserType} setuserData={setuserData} /> },
      { path: 'login', element: <Login setToken={setToken} setAccess={setAccess} setUserType={setUserType} setuserData={setuserData} /> },
      { path: '404', element: <NotFound /> },
      { path: '*', element: <Navigate to="/login" /> }
    ]
  }]

  const UPGRADE_LAYOUT = [{
    path: '/',
    element: <LogoOnlyLayout />,
    children: [
      { path: '/', element: <Navigate to="/licence" /> },
      { path: 'auto-login', element: <AutoLogin setToken={setToken} setAccess={setAccess} setUserType={setUserType} setuserData={setuserData} /> },
      { path: 'login', element: <Login setToken={setToken} setAccess={setAccess} setUserType={setUserType} setuserData={setuserData}/> },
      { path: 'licence', element: <LicenceUpgrade /> },
      { path: '404', element: <NotFound /> },
      { path: '*', element: <Navigate to="/licence" /> }
    ]
  }]
  
  const DEFAULT_RDT = { path: '*', element: <Navigate to="/404" replace /> }
  
  const RUTS = [...token ? (access ? DASH_LAYOUT : UPGRADE_LAYOUT) : LOGO_LAYOUT, DEFAULT_RDT]
  return useRoutes(RUTS);
}
