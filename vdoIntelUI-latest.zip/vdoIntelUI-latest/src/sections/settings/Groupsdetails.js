


import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  Card,
  Table,
  Stack,
  Button,
  TableRow,
  TableBody,
  TableCell,
  Container,
  Typography,
  TableContainer,
} from '@mui/material';
// import UserListToolbar from '../../src/sections/@dashboard/user/UserListToolbar';
// import UserListHead from '../../src/sections/@dashboard/user/UserListHead';
// import Label from '../../src/components/Label.js';
// import ShiftTimeMoreMenu from 'src/sections/shifttime/ShiftTimeMoreMenu.js';
// import ShiftTimeAdd from 'src/sections/shifttime/shiftTimeAdd.js';
// import ShiftTimeEdit from 'src/sections/shifttime/shiftTimeEdit.js';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import { ListItemText } from '@mui/material';
import Iconify from 'src/components/Iconify';
import {
  CardContent,
  
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Grid,
  Box,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  TableHead,
} from '@mui/material';

const Groupsdetails= () => {
  const [data, setData] = useState([]);
  const [filterName, setFilterName] = useState('');
  const [selectedClient, setSelectedClient] = useState(null); // State for selected client
  const [clients, setClients] = useState([]); // State for storing client data
  const [clientOptions, setClientOptions] = useState([]); // State for autocomplete options
  const [client, setClient] = useState('');
  const [camera, setCamera] = useState('');
  const [group, setGroup] = useState('');
  const [groupName, setGroupName] = useState('');
  const [open, setOpen] = useState(false);
  const [errorMessageOpen, setErrorMessageOpen] = useState(false);
  const [selectedCameras, setSelectedCameras] = useState([]);

  // Dummy camera options
  const cameraOptions = [
    { value: 'camera1', label: 'Camera 1' },
    { value: 'camera2', label: 'Camera 2' },
    { value: 'camera3', label: 'Camera 3' },
  ];

  useEffect(() => {
    const fetchClients = async () => {
      try {
        const response = await axios.get('http://your-api-url/clients');
        setClients(response.data);
        // Extract client names for autocomplete options
        const options = response.data.map(client => client.name);
        setClientOptions(options);
      } catch (error) {
        console.error('Error fetching clients:', error);
      }
    };

    fetchClients();
  }, []);

  const handleFilterByName = event => {
    setFilterName(event.target.value);
    // Perform additional filtering based on the selected client if needed
  };

  const handleOpen = () => {
    setOpen(true);
  };
  const handleCameraChange = (event, newValue) => {
    setSelectedCameras(newValue);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleSave = () => {
    if (!client || !camera || !group || !groupName) {
      setErrorMessageOpen(true);
    } else {
      // Handle save logic here
      console.log('Group Name:', groupName);
      setGroupName('');
      setOpen(false);
    }
  };

  const handleErrorMessageClose = () => {
    setErrorMessageOpen(false);
  };

  const handleGroupNameChange = event => {
    setGroupName(event.target.value);
  };
  const sampleData = [
    { cameraName: 'Camera 1', groupName: 'Group 1' },
    { cameraName: 'Camera 2', groupName: 'Group 2' },
    { cameraName: 'Camera 3', groupName: 'Group 3' },
    // Add more sample data as needed
  ];

  return (
    <>
<Stack direction="row" alignItems="center" justifyContent="space-between" mb={5} sx={{ marginBottom: 3 }}>
<Typography variant="h4" gutterBottom sx={{ pl: 23}}>
          Groups
        </Typography>
        <div>
          {/* <Button variant="contained" onClick={handleOpen} > */}
          <Button
  variant="contained"
  onClick={() => handleOpen()}
  startIcon={<Iconify icon="eva:plus-fill" />}
  sx={{ marginRight: 23 }}
>
  Add Group
</Button>


          
          <Dialog open={open} onClose={handleClose} maxWidth="xs" fullWidth>
  <DialogTitle>Add Camera</DialogTitle>
  
    {/* Add camera form fields */}
    <DialogContent>
              <TextField
                autoFocus
                margin="dense"
                id="groupName"
                label="Group Name"
                type="text"
                fullWidth
                value={groupName}
                onChange={handleGroupNameChange}
                required
              />
  </DialogContent>
  <DialogActions>
    <Button onClick={handleClose}>Close</Button>
    <Button onClick={handleSave}>Save</Button>
  </DialogActions>
</Dialog>

        </div>
      </Stack>

     
      <Card sx={{ width: '80%', p: 2, margin: 'auto' }}>
  <CardContent>
    <Grid container spacing={3}>
      <Grid item xs={3}>
        <FormControl fullWidth>
          <InputLabel id="client-label">Client</InputLabel>
          <Select
            labelId="client-label"
            id="client"
            value={client}
            onChange={e => setClient(e.target.value)}
            label="Client"
            required
          >
            <MenuItem value="client1">Client 1</MenuItem>
            <MenuItem value="client2">Client 2</MenuItem>
            <MenuItem value="client3">Client 3</MenuItem>
          </Select>
        </FormControl>
      </Grid>
      <Grid item xs={3}>
      <Autocomplete
        multiple
        fullWidth
        id="camera"
        options={cameraOptions}
        value={selectedCameras}
        onChange={handleCameraChange}
        getOptionLabel={(option) => option.label}
        renderInput={(params) => <TextField {...params} label="Camera" />}
      />
    </Grid>
      <Grid item xs={3}>
        <FormControl fullWidth>
          <InputLabel id="group-label">Group</InputLabel>
          <Select
            labelId="group-label"
            id="group"
            value={group}
            onChange={e => setGroup(e.target.value)}
            label="Group"
            required
          >
            <MenuItem value="group1">Group 1</MenuItem>
            <MenuItem value="group2">Group 2</MenuItem>
            <MenuItem value="group3">Group 3</MenuItem>
          </Select>
        </FormControl>
      </Grid>
      <Grid item xs={3}>
        <Button variant="contained" onClick={handleSave} sx={{ mt: 2 }}>
          Save
        </Button>
      </Grid>
    </Grid>
  </CardContent>
 
  <TableContainer>
  <Table>
    <TableHead sx={{ background: '#f3f3f3' }}>
      <TableRow>
        <TableCell sx={{ background: '#f3f3f3' }}>S.No</TableCell>
        <TableCell sx={{ background: '#f3f3f3' }}>Camera Name</TableCell>
        <TableCell sx={{ background: '#f3f3f3' }}>Group Name</TableCell>
      </TableRow>
    </TableHead>
    <TableBody>
  {sampleData.map((row, index) => (
    <TableRow key={index}>
      <TableCell>{index + 1}</TableCell>
      <TableCell>{row.cameraName}</TableCell>
      <TableCell>{row.groupName}</TableCell>
    </TableRow>
  ))}
</TableBody>

  </Table>
</TableContainer>

</Card>
</>
  );
};

export default Groupsdetails;
