
import React, { useEffect, useState } from 'react';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import { ListItemText, useRadioGroup } from '@mui/material';
import { LoadingButton } from '@mui/lab';

import Iconify from 'src/components/Iconify';

import axios from 'src/axios';
import {
  CardContent,
  Card,
  Table,
  Stack,
  Button,
  TableRow,
  TableBody,
  TableCell,
  Container,
  Typography,
  TableContainer,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Grid,
  Box,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  TableHead,
} from '@mui/material';
import Page from 'src/components/Page';
import { getCamerasList , getClientList} from 'src/api/analytics';

import { getProtocols , setAddProtocol ,getClientInfo , setSaveProtocol } from 'src/api/protocol';
  
const Protocols= () => {

const [setClient,setSelectedClient] = useState([]);
const [clientName,selectedClientName] = useState([]);
const [cameraList,setCameras] = useState([]);
const [selectedCamesList,setCamsList] = useState([]);
const [selectedCamItems, setCamSelectedItems] = useState([]);


const [protocolList,setProtocols] = useState([]); 
const [open, setOpen] = useState(false);
const [newProtocolname,setNewProtoName] = useState('');
const [selectedProto,setSelectedProtocol] = useState([]);


const [clientInfo,setClientDetails] = useState([]);

// Form Fields

// police Number 
const [policeno, setPoliceNo] = useState('');

//mobile number 
const [mobileno, setMobileNo] = useState('');

//emil Change

const [email, setEmail] = useState('');

//Fire Number
const [fireNo, setFireNo] = useState('');

// address
const [address, setAddress] = useState('');

// Client ID mandatory 
const [isClientSelected, setIsClientSelected] = useState(false); // State variable to track client selection
const [saveError, setSaveError] = useState(false); // State to track save error

// Add new protocol Error
const [protocolNameError, setProtocolNameError] = useState(false);


const handlePoliceNoChange = (event) => {
  setPoliceNo(event.target.value);
};


const handleMobileChange = (event) => {
  setMobileNo(event.target.value);
};

const handleEmailChange = (event) => {
  setEmail(event.target.value);
};

const handleFireChange = (event) => {
  setFireNo(event.target.value);
};

const handleAddressChange = (event) => {
  setAddress(event.target.value);
};

  useEffect(() => {

    getClientList((response) => {
      if (response.status === 200) {
        setSelectedClient(response.data)
      }
    })

    getCamerasList((response) => {
      if (response.status === 200) {
        setCameras(response.data)
      }
    })

    getProtocols((response) => {
      if (response.status === 200) {
        setProtocols(response.data)
        console.log('protocols',response.data);

      }
    })

  },[])

  useEffect(() => {
    const matchedCameras = cameraList.filter(camera => camera.clientid === clientName.ID);
    console.log("cameras", matchedCameras);
    setCamsList(matchedCameras)

    getClientInfo(clientName.ID,(response) => {
      if (response.status === 200) {
        setClientDetails(response.data);
      }
    })

  },[clientName.ID])


  useEffect(() => {
    // setFianlClientData([]);
    if(clientInfo.length == 1){
      console.log("clientInfo Length" ,clientInfo)

      setPoliceNo(clientInfo[0].PoliceNo)
      setMobileNo(clientInfo[0].MobileNo)
      setAddress(clientInfo[0].Address)
      setFireNo(clientInfo[0].FireNo)
      setEmail(clientInfo[0].Email)
    }
    else{
      // setFianlClientData([]);

      setPoliceNo('')
      setMobileNo('')
      setAddress('')
      setFireNo('')
      setEmail('')
    }

  },[clientInfo])

const handleClient = (_, value) => {
  if (!value) {
    selectedClientName([]);
    setCamSelectedItems([]);
    setCamsList([]); 
    setPoliceNo('')
    setMobileNo('')
    setAddress('')
    setFireNo('')
    setEmail('')
    setIsClientSelected(false);
    setSaveError(false);
  } else {

  console.log("selected client ", value);  
  selectedClientName(value)
  setIsClientSelected(true);
  }
};



const handleCamera = (event, newValue) => {
  setCamSelectedItems(newValue);
  // handleCamera(newValue); // Call your onChange handler with the updated value
};

// add protocol 

const handleOpen = () => {
  setOpen(true);
};
const handleClose = () => {
  setOpen(false);
  setNewProtoName('');
  setProtocolNameError(false);
};

const handleAddNewProtocol = () => {


  if (newProtocolname.trim() === '') {
    setProtocolNameError(true);
  }
  else {

  
    const data = {
      IntrusionType: newProtocolname,
    };
  
  const jsonData = JSON.stringify(data);
  
  console.log("data", jsonData);
  
    setAddProtocol(data, (response) => {
      if(response.status === 200) {
        console.log('Protocol Name:',response);
  
  
        setOpen(false);
        getProtocols((response) => {
          if (response.status === 200) {
            setProtocols(response.data)
            console.log('protocols',response.data);
    
          }
        })
      }
    })
  
      setOpen(false);
      setProtocolNameError(false);

  }

  
};

const handleProtocol = (event ,newValue) => {
   if(newValue){
    setSelectedProtocol(newValue);
   }
   else {
    setSelectedProtocol([]);
   }


}

// complete Protocol Save 

const handleProtocolSave = () => {

  if (!isClientSelected) {
    setSaveError(true); // Set save error if client is not selected
    return;
  }

const data = {
  ClientId: clientName.ID,
  PoliceNo: policeno,
  FireNo: fireNo,
  Address:address,
  Email: email,
  MobileNo: mobileno
};
  
setSaveProtocol(data, (response) => {
    if(response.status === 200) {
      console.log('Protocol Name:',response);
      setPoliceNo('')
      setMobileNo('')
      setAddress('')
      setFireNo('')
      setEmail('')
    }
  })


}

// Add New Messages 

const [messages, setMessages] = useState([]);

const addMessage = () => {
  setMessages([...messages, '']); // Add an empty message to the messages array
};

const removeMessage = (index) => {
  const updatedMessages = [...messages];
  updatedMessages.splice(index, 1); // Remove the message at the given index
  setMessages(updatedMessages);
};

const handleChangeText = (index) => (event) => {
  const updatedMessages = [...messages];
  updatedMessages[index] = event.target.value; // Update the message at the given index
  setMessages(updatedMessages);
};



  return (
<>
<Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>
          <Typography variant="h4" gutterBottom>
            Protocols
          </Typography>
          <Button variant="contained" to="#" 
         onClick={() => handleOpen()} startIcon={<Iconify icon="eva:plus-fill" />}
          
          >
            Add Protocols
          </Button>

        </Stack>

<Card style={{ marginBottom: '5px' }}>


<CardContent style={{ marginBottom: '-25px' }}>
                 
            <Grid container spacing={2}>                           
                          <Grid item md={4}>
                              <FormControl fullWidth>
                                              
                                  <Autocomplete                                
                                      id="tags-outlined-client"
                                      options={setClient}
                                      getOptionLabel={(option) => `${option.Name}`}
                                      onChange={handleClient}
                                      value={clientName.ID}
                                      renderInput={(params) => (
                                        <TextField
                                          {...params}
                                          label="Select Client"
                                          placeholder="Search Client Name..."
                                          error={saveError && !isClientSelected} // Add error state based on saveError and isClientSelected
                                              />
                                            )}
                                          />
                                          {(saveError && !isClientSelected) && ( // Show error message if saveError and !isClientSelected
                                            <Typography variant="body2" color="error">
                                              Please select a client.
                                            </Typography>
                                          )}
                                                        
                              </FormControl>
                            </Grid>
                            <Grid item md={4}>
                                <FormControl fullWidth>
                                      <Autocomplete
                                          multiple
                                          id="tags-outlined-client"
                                          options={selectedCamesList}
                                          getOptionLabel={(option) => `${option.deviceid} ${option.devicename}`}
                                          onChange={handleCamera}
                                          value={selectedCamItems}
                                          renderInput={(params) => (
                                            <TextField
                                              {...params}
                                              label="Select Cameras"
                                              placeholder="Search Camera Name..."
                                            />
                                          )}
                                        />

                                                  {/* <FormHelperText style={{ color: 'red' }}>{formErrors[`${index}.CameraView`] || ''}</FormHelperText> */}
                                 </FormControl>

                            </Grid>
                            <Grid item md={4}>
                                <FormControl fullWidth>
                                                  <Autocomplete                                
                                                    id="tags-outlined-client"
                                                    options={protocolList}
                                                    getOptionLabel={(option) => `${option.IntrusionType}`}
                                                    onChange={handleProtocol}
                                                    value={selectedProto.Id}
                                                    renderInput={(params) => (
                                                      <TextField
                                                        {...params}
                                                        label="Select Protocol"
                                                        placeholder="Search Protocol Name..."
                                                      />
                                                    )}
                                                  />
                                                  
                                                  {/* <FormHelperText style={{ color: 'red' }}>{formErrors[`${index}.CameraView`] || ''}</FormHelperText> */}
                                 </FormControl>

                            </Grid>
              </Grid>
  </CardContent> 
  <CardContent style={{ marginBottom: '-16px' }}>


              <Grid container spacing={2}>                           
                          <Grid item md={3}>
                          <TextField
                            fullWidth
                            label="Police Number"
                            value={policeno}
                            onChange={handlePoliceNoChange}
                            InputLabelProps={{
                              shrink: !!policeno,
                            }}
                          />

                            </Grid>
                            <Grid item md={3}>
                                <TextField
                                  fullWidth
                                  label="Fire Number"
                                  value={fireNo}
                                  onChange={handleFireChange}
                                  InputLabelProps={{
                                    shrink: !!fireNo,
                                  }}
                                />

                            </Grid>
                            <Grid item md={3}>
                                <TextField
                                  fullWidth
                                  label="Email"
                                  value={email}
                                  onChange={handleEmailChange}
                                  InputLabelProps={{
                                    shrink: !!email,
                                  }}
                                />

                            </Grid>
                            <Grid item md={3}>
                                <TextField
                                  fullWidth
                                  label="Contact Number"
                                  value={mobileno}
                                  onChange={handleMobileChange}
                                  InputLabelProps={{
                                    shrink: !!mobileno,
                                  }}
                                />

                            </Grid>
                            <Grid item md={3}>
                                <TextField
                                  fullWidth
                                  label="Address"
                                  value={address}
                                  onChange={handleAddressChange}
                                  InputLabelProps={{
                                    shrink: !!address,
                                  }}
                                />

                            </Grid>
                       
              </Grid>

  </CardContent> 
  <DialogActions>
                          {/* <Button color='error' variant='outlined' >Clear</Button> */}
                          <LoadingButton type="submit"  onClick={handleProtocolSave} variant='outlined'>Save</LoadingButton>
  </DialogActions>      


 
</Card>

<Card >



  <CardContent style={{ marginBottom: '-16px' }}>
      <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>
        <Typography variant="h4" gutterBottom>
          Messages
        </Typography>
        <Button variant="contained" onClick={addMessage} startIcon={<Iconify icon="eva:plus-fill" />}>
          Add New Message
        </Button>
      </Stack>
      <Grid container spacing={2}>
        {messages.map((message, index) => (
          <>
                    <Grid item md={10} key={index}>
                      <FormControl fullWidth>
                        <TextField
                          fullWidth
                          label="Message"
                          value={message}
                          onChange={handleChangeText(index)}
                        />
                      </FormControl>
                    </Grid>
                    <Grid item md={1}>
                      <FormControl fullWidth>
                        <Button color='error' variant='outlined' onClick={() => removeMessage(index)}>Remove</Button>
                      </FormControl>
                    </Grid>
          </>

        ))}
      </Grid>
    </CardContent>

                         <DialogActions>
                          {/* <Button color='error' variant='outlined' >Clear</Button> */}
                          <LoadingButton type="submit"  variant='outlined'>Save Messages</LoadingButton>
                        </DialogActions> 

</Card>



{/* add protocol popup  */}
<Dialog open={open} onClose={handleClose} maxWidth="xs" fullWidth>
  <DialogTitle>Add protocol</DialogTitle>
  
    {/* Add camera form fields */}
    <DialogContent>
              <TextField
                autoFocus
                margin="dense"
                id="protocolName"
                label="Protocol Name"
                type="text"
                fullWidth
                value={newProtocolname}
                onChange={(e) => {
                  setNewProtoName(e.target.value);
                  setProtocolNameError(false); // Reset error state when typing
                }}
                error={protocolNameError}
                helperText={protocolNameError ? 'Protocol Name cannot be empty' : ''}
                required
              />
  </DialogContent>
  <DialogActions>

            <Button color='error'  onClick={handleClose} variant='outlined' >Close</Button>
          <LoadingButton type="submit" onClick={handleAddNewProtocol}  variant='outlined'>Save</LoadingButton>
  </DialogActions>
</Dialog>

</>
  );
};

export default Protocols;
