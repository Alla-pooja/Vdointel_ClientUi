import React, { useState, useEffect } from 'react';
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, Typography, TextField, Switch,  Box } from '@mui/material';
import axios from "axios";
import { LoadingButton } from '@mui/lab';
import Autocomplete from '@mui/material/Autocomplete';


import {

  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from '@mui/material';

// import { top100Films } from './data'; // Import your data
const TimeLapsEdit = ({ isOpen, onClose, currentId, rowData, updateDataCallback }) => {
  const [editedData, setEditedData] = useState({});
  const [data, setData] = useState([]);
  const [dataDevicesId, setDataDevicesId] = useState([]);


  useEffect(() => {
    // Set initial values when rowData changes
    setEditedData({...rowData});
  }, [rowData]);

  const handleSave = async () => {
    
    try {
      // Make a PUT request to your API endpoint with the edited data
      const updatedData = {
        ...rowData,
        Id: editedData.Id || rowData.Id,
        CameraId: editedData.CameraId || rowData.CameraId,
        ProcessFps: editedData.ProcessFps || rowData.ProcessFps,
        VideoFps: editedData.VideoFps || rowData.VideoFps,
        SegmentTime: editedData.SegmentTime || rowData.SegmentTime,
        IsActive: editedData.IsActive || rowData.IsActive,
      };
      console.log("look",updatedData.IsActive);
      await axios.put(`http://192.168.30.68:8080/time-laps/update-time-laps-settings`, updatedData);
      // If successful, you can handle any additional logic or close the dialog
      updateDataCallback();
      onClose();
    } catch (error) {
      // Handle error, e.g., show an error message
      console.error('Error saving data:', error);
    }
  };

  const handleChange = (key, value) => {
    console.log(key, value )
    // const prevData = {...editedData}
    // prevData[key] = value
    // setEditedData({...prevData})
    setEditedData((prevData) => {
      prevData[key] = value
      return {...prevData}
    });
  };

  const fieldsToShow = ['CameraId','ProcessFps', 'VideoFps', 'SegmentTime', 'IsActive'];

  useEffect(() => {
    const fetchData = async () => {
      const apiUrl = 'http://192.168.30.68:8080/devices/cameras';
      const AUTH_TOKEN = `${localStorage.getItem('token_type')} ${localStorage.getItem('access_token')}`;
      console.log('AUTH_TOKEN',AUTH_TOKEN);
      try {
        const response = await axios.get(apiUrl, {
          headers: {
            Authorization: `${AUTH_TOKEN}`,
          },
        });

        // Handle successful response
        setDataDevicesId(response.data);
        console.log("Token get api", response.data);
      } catch (error) {
        // Handle error
        console.error('Error:', error);
      }
    };

    fetchData();
  }, []);

  
  const temId = dataDevicesId.map(item => item.deviceid);

  return (
    <Dialog open={isOpen} onClose={onClose}>
      <DialogTitle  style={{ marginBottom: 10}}>Edit TimeLaps</DialogTitle>
      <DialogContent >
      {fieldsToShow.map((key) => (
        <React.Fragment key={key}>
          {key === 'CameraId' ? (

            <Autocomplete
            options={temId}
            getOptionLabel={(option) => option}
            value={editedData[key] || rowData.CameraId || null}
            onChange={(_, newValue) => handleChange(key, newValue)}
            renderInput={(params) => (
              <TextField
                {...params}
                label="CameraId"
                fullWidth
                margin="normal"
              />
            )}
            />
          )  : key === 'IsActive' ? (
                <>
                <Box>
                  <Typography variant='subtitle2'>Active state</Typography>
                  <Typography>Disabling this will automatically set to InActive</Typography> 
                </Box>  
            
                <Switch
              color="success"
              checked={editedData.IsActive === 1 }
              onChange={() => {handleChange(key, editedData.IsActive === '0' ? 1 : '0' )}}
              />

                </>
               
            ) : (
              <TextField
                label={key}
                value={editedData[key] || 0}
                onChange={(e) => handleChange(key, e.target.value)}
                fullWidth
                margin="normal"
               
              />
            )}
          </React.Fragment>
        ))}
      </DialogContent>
      <DialogActions>
        <Button color='error' variant='outlined' onClick={onClose}>
          Close
        </Button>
        <LoadingButton
          type="submit"
          variant="contained"
          onClick={handleSave}
        >
          Save Changes
        </LoadingButton>
      </DialogActions>
    </Dialog>
  );
};

export default TimeLapsEdit;


