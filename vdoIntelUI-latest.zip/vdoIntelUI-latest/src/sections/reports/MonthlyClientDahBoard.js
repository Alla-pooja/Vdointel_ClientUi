import React, { useState,useEffect, useRef } from 'react';
import { filter, result } from 'lodash';
import BarChart from './BarChart';
import Iconify from 'src/components/Iconify';
import {
  InputAdornment,
  Grid,
  Box,
  Autocomplete,
  Button,
  TextField,
  Typography,
  TableCell,
  TableRow,
  TableBody,
  Table,
  TableHead,
  TableContainer,TablePagination,Toolbar,OutlinedInput
} from '@mui/material';

import PropTypes from 'prop-types';
import Scrollbar from 'src/components/Scrollbar';
import { DemoContainer, DemoItem } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { YearCalendar } from '@mui/x-date-pickers/YearCalendar';
import { Select, MenuItem } from '@mui/material';
import { styled } from '@mui/material/styles';
import { Page, Text, View, Document, StyleSheet, Image,pdf,PDFDownloadLink,PDFViewer } from '@react-pdf/renderer';
// import logoImage from '../../assets/logo.svg'
import { ViewAgenda } from '@mui/icons-material';
import { Bar } from 'react-chartjs-2';
import { createRoot } from 'react-dom/client'; 
// import {ChartJsImage} from 'chartjs-to-image';
import Chart from 'chart.js/auto';


const RootStyle = styled(Toolbar)(({ theme }) => ({
    height: 96,
    display: 'flex',
    // justifyContent: 'space-between',
    padding: theme.spacing(0, 1, 0, 3),
  }));

const SearchStyle = styled(OutlinedInput)(({ theme }) => ({
    width: 240,
    marginLeft: 15,
    transition: theme.transitions.create(['box-shadow', 'width'], {
      easing: theme.transitions.easing.easeInOut,
      duration: theme.transitions.duration.shorter,
    }),
    '&.Mui-focused': { width: 320, boxShadow: theme.customShadows.z8 },
    '& fieldset': {
      borderWidth: `1px !important`,
      borderColor: `${theme.palette.grey[500_32]} !important`,
    },
  }));


const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
const currentYear = new Date().getFullYear();
const years = [currentYear - 1,currentYear,currentYear + 1];

const options3 = ['Choice X', 'Choice Y', 'Choice Z'];

const styles = StyleSheet.create({
    page: {
      flexDirection: 'row',
      backgroundColor: 'white'
    },
    section: {
      margin: 10,
      padding: 10,
      flexGrow: 1
    },
    image: {
      width: 200,
      height: 100
    },
    chartContainer: {
        width: '100%',
        height: 200,
        marginTop: 20,
      },
  });

const MonthlyClientDahBoard = ({clientList}) => {
  const [filterName, setFilterName] = useState('');  

  const [value1, setValue1] = useState(null);
  const [value2, setValue2] = useState(null);
  const [value3, setValue3] = useState(null);

  const [showChart,setShowChart]=useState(false)

  const handleButtonClick = () => {
    // handle form submission

    setShowChart(!showChart)

    console.log('Dropdown 1 value:', value1);
    console.log('Dropdown 2 value:', value2);
    console.log('Dropdown 3 value:', value3);
  };

    const columns = [
        { id: 'Sno', name: 'Sno' },
        { id: 'EventNo', name: 'Event Number' },
        { id: 'CameraName', name: 'Camera Name' },
        { id: 'EscalationUrl', name: 'Escalation Url' }
    ]

    const values = [
        { EventNo: '123', CameraName: 'test1', EscalationUrl: 'abc.com' },
        { EventNo: '456', CameraName: 'test2', EscalationUrl: 'def.com' },
        { EventNo: '789', CameraName: 'test3', EscalationUrl: 'ghi.com' },
        { EventNo: '101112', CameraName: 'test4', EscalationUrl: 'jkl.com' },
        { EventNo: '131415', CameraName: 'test5', EscalationUrl: 'mno.com' },
        { EventNo: '161718', CameraName: 'test6', EscalationUrl: 'pqr.com' },
        { EventNo: '192021', CameraName: 'test7', EscalationUrl: 'stu.com' },
        { EventNo: '222324', CameraName: 'test8', EscalationUrl: 'vwx.com' },
        { EventNo: '252627', CameraName: 'test9', EscalationUrl: 'yz.com' },
        { EventNo: '282930', CameraName: 'test10', EscalationUrl: 'xyz.com' }
    ];

const [data, setData] = useState([])
const [row,rowChange] = useState([])
const [page,pageChange]=useState(0)
const [rowPerPage,rowPerPageChange]=useState(5)

useEffect(() => {
    setData(values)
}, [])

const handleChangePage = (event,newpage)=>{
    if(newpage===0){
        pageChange(0);
    }
    else{
        pageChange(newpage)
    }
}

const handleRowsPerPage = (e)=>{
    rowPerPageChange(e.target.value)
    pageChange(0)
}

const handleFilterByName = (event) => {
    const pattern=event.target.value.trim()
    setFilterName(pattern);
  };

  useEffect(()=>{
    console.log(filterName)
  },[filterName])

  const convertImageToBase64 = (file, callback) => {
    debugger
    const reader = new FileReader();
    reader.onloadend = () => {
      callback(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const pieChartData = [
    { cameraname: 'abc', trueevents: '15', falseevents: '2' },
    { cameraname: 'def', trueevents: '10', falseevents: '5' },
    { cameraname: 'hij', trueevents: '20', falseevents: '8' },
    { cameraname: 'klm', trueevents: '12', falseevents: '3' },
    { cameraname: 'nop', trueevents: '18', falseevents: '6' },
    { cameraname: 'qrs', trueevents: '14', falseevents: '4' },
    { cameraname: 'tuv', trueevents: '9', falseevents: '7' },
    { cameraname: 'wxy', trueevents: '22', falseevents: '10' },
    { cameraname: 'zab', trueevents: '17', falseevents: '1' },
    { cameraname: 'cde', trueevents: '13', falseevents: '9' }
  ];

  const cameraNames = pieChartData.map(item=>item.cameraname)
  const trueEvents=pieChartData.map(item=>item.trueevents)
  const falseEvents=pieChartData.map(item=>item.falseevents)

  //console.log(cameraNames,trueEvents,falseEvents)
  const PDFData = () => {
  
    const logoImagePath = '/static/media/preview.jpg'; 

    const handleImageLoad = (file) => {
      convertImageToBase64(file, (result) => {
        console.log(result); // Log the base64 string
      });
    };
  
    return (
      <Document>
        <Page size="A4">
          <View style={{width:100,marginTop:20,height:40}}>
            {/* <Image src={logoImagePath} onLoadSuccess={({ file }) => handleImageLoad(file)} /> */}
            <Image src='/static/logonew.png'/>            
          </View>
         
          <View style={{marginTop:20}}>
               <Text style={{ fontSize: 12, fontWeight: 'bold',marginLeft:10 }}>VDOintel Service Overview Dashboard</Text> 
          </View>
          
          <View style={{ marginTop: 20, backgroundColor: 'black',color: 'white',textAlign: 'center',padding: 10,marginLeft:10,marginRight:10}}>
                <Text style={{ fontSize: 12 }}>SERVICE HIGHLIGHTS</Text>
          </View>
          
          <View style={{display:'flex',flexDirection:'row',marginTop:2,marginLeft:10,marginRight:10}}>
            <View style={{ flex: 3 }}>
                <Text style={{ fontSize: 12, fontWeight: 'bold',backgroundColor: 'black',color: 'white',textAlign: 'center',padding:10 }}>SERVICE PERIOD</Text>
                <Text style={{fontSize:12,fontWeight:'bold',textAlign:'center',marginTop:5}}>2022-2023</Text>
            </View>
            <View style={{ flex: 5 }} />
            <View style={{ flex: 4 }}>
                <Text style={{ fontSize: 12, fontWeight: 'bold',backgroundColor: 'black',color: 'white',textAlign: 'center',padding:10 }}>NUMBER OF CAMERAS</Text>
                <Text style={{fontSize:12,fontWeight:'bold',textAlign:'center',marginTop:5}}>10</Text>
            </View>
          </View>

          <View style={{display:'flex',flexDirection:'row',marginTop:5,marginLeft:10,marginRight:10}}>
          <View style={{ flex: 3 }}>
                <Text style={{ fontSize: 12, fontWeight: 'bold',backgroundColor: 'black',color: 'white',textAlign: 'center',padding:3.5 }}>TOTAL EVENTS{'\n'}TRIGGERED</Text>
                <Text style={{fontSize:12,fontWeight:'bold',textAlign:'center',marginTop:5}}>10</Text>
            </View>
            <View style={{ flex: 5,marginLeft:1,marginRight:1 }}>
                <Text style={{ fontSize: 12, fontWeight: 'bold',backgroundColor: 'black',color: 'white',textAlign: 'center',padding:10 }}>TOTAL ESCALATIONS</Text>
                <Text style={{fontSize:12,fontWeight:'bold',textAlign:'center',marginTop:5}}>10</Text>
            </View>
            <View style={{ flex: 4 }}>
                <Text style={{ fontSize: 12, fontWeight: 'bold',backgroundColor: 'black',color: 'white',textAlign: 'center',padding:10 }}>TOTAL ESCALATIONS</Text>
                <Text style={{fontSize:12,fontWeight:'bold',textAlign:'center',marginTop:5}}>10</Text>
            </View>
          </View>

          <View style={{ marginTop: 20, backgroundColor: 'black',color: 'white',textAlign: 'center',padding: 10,marginLeft:10,marginRight:10}}>
             <Text style={{fontSize:12,fontWeight:'bold'}}>TREND OF AUDITS BY CAMERA</Text>
          </View>

          <View style={styles.chartContainer}>   
                {/* {showChart && <BarChart/>} */}
          </View>
        </Page>
      </Document>
    );
}


  return (
    <Grid sx={{ marginLeft: '1rem' }}>
        <Grid container spacing={2} alignItems="center" sx={{marginTop:'0.2rem'}}>
        
            <Grid item xs={3}>
                <Typography variant="subtitle2" component="div">
                Client{' '}
                <Typography
                    variant="subtitle1"
                    component="span"
                    sx={{ color: 'red', display: 'inline' }}
                >
                    *
                </Typography>
                </Typography>
                <Autocomplete
                value={value3}
                onChange={(event, newValue) => {
                    setValue3(newValue);
                }}
                options={options3}
                renderInput={(params) => (
                    <TextField
                    {...params}
                    placeholder="Select Client"
                    variant="outlined"
                    />
                )}
                />
            </Grid>

            <Grid item xs={3}>
                <Typography variant='subtitle2' component="div">
                Month{' '}
                <Typography
                    variant="subtitle1"
                    component="span"
                    sx={{ color: 'red', display: 'inline' }}
                >
                    *
                </Typography>
                </Typography>

                <Autocomplete
                value={value1}
                onChange={(event, newValue) => {
                    setValue1(newValue);
                }}
                options={months}
                renderInput={(params) => (
                    <TextField
                    {...params}
                    placeholder="Select Month"
                    variant="outlined"
                    />
                )}
                />
            </Grid>
            
            <Grid item xs={3}>
                <Typography variant="subtitle2" component="div">
                Year{' '}
                <Typography
                    variant="subtitle1"
                    component="span"
                    sx={{ color: 'red', display: 'inline' }}
                >
                    *
                </Typography>
                </Typography>
                <Autocomplete
                value={value2}
                onChange={(event, newValue) => {
                    setValue2(newValue);
                }}
                options={years}
                renderInput={(params) => (
                    <TextField
                    {...params}
                    placeholder="Select Year"
                    variant="outlined"
                    />
                )}
                />
            </Grid>

            <Grid item xs={1} sx={{marginTop:2}}>
                    <Button variant="contained" onClick={handleButtonClick}>
                      Generate
                    </Button>           
            </Grid>

            <Grid item xs={3}>
                <Typography variant="subtitle2" component="div">
                Group{' '}
                <Typography
                    variant="subtitle1"
                    component="span"
                    sx={{ color: 'red', display: 'inline' }}
                >
                    *
                </Typography>
                </Typography>
                <Autocomplete
                value={value2}
                onChange={(event, newValue) => {
                    setValue2(newValue);
                }}
                options={years}
                renderInput={(params) => (
                    <TextField
                    {...params}
                    placeholder="Select Group"
                    variant="outlined"
                    />
                )}
                />
            </Grid>

        
        </Grid>

      
        <Grid container spacing={2} alignItems="center" sx={{ marginTop: '2rem' }}>
            <PDFDownloadLink document={<PDFData />} fileName="MonthlyClinetDashBoard.pdf">
                    {({ blob, url, loading, error }) => (
                    <Button variant="contained" disabled={loading} onClick={!loading ? null : () => {}}>
                        {loading ? 'Loading document...' : 'Download File'}
                    </Button>
                    )}
            </PDFDownloadLink>
            <PDFViewer style={{ width: '100%', height: '900px' }} showToolbar={false}>
                <PDFData />
            </PDFViewer>
        </Grid>

        
    </Grid>
  );
};

export default MonthlyClientDahBoard;