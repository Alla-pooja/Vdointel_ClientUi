import React, { useState,useEffect } from 'react';
import { filter } from 'lodash';
import Iconify from 'src/components/Iconify';
import {
  InputAdornment,
  Grid,
  Box,
  Autocomplete,
  Button,
  TextField,
  Typography,
  TableCell,
  TableRow,
  TableBody,
  Table,
  TableHead,
  TableContainer,TablePagination,Toolbar,OutlinedInput, Stack
} from '@mui/material';
import PropTypes from 'prop-types';
import Scrollbar from 'src/components/Scrollbar';
import { styled } from '@mui/material/styles';
import { Construction } from '@mui/icons-material';
//import OutlinedInput from '@mui/material';

const RootStyle = styled(Toolbar)(({ theme }) => ({
    height: 96,
    display: 'flex',
    // justifyContent: 'space-between',
    padding: theme.spacing(0, 1, 0, 3),
  }));

const SearchStyle = styled(OutlinedInput)(({ theme }) => ({
    width: 240,
    marginLeft: 15,
    transition: theme.transitions.create(['box-shadow', 'width'], {
      easing: theme.transitions.easing.easeInOut,
      duration: theme.transitions.duration.shorter,
    }),
    '&.Mui-focused': { width: 320, boxShadow: theme.customShadows.z8 },
    '& fieldset': {
      borderWidth: `1px !important`,
      borderColor: `${theme.palette.grey[500_32]} !important`,
    },
  }));

  const months = [
    { name: 'January', value: '1' },
    { name: 'February', value: '2' },
    { name: 'March', value: '3' },
    { name: 'April', value: '4' },
    { name: 'May', value: '5' },
    { name: 'June', value: '6' },
    { name: 'July', value: '7' },
    { name: 'August', value: '8' },
    { name: 'September', value: '9' },
    { name: 'October', value: '10' },
    { name: 'November', value: '11' },
    { name: 'December', value: '12' }
  ];


const MonthlyEscalationReport = ({clientList}) => {

  const options3 =clientList //['Choice X', 'Choice Y', 'Choice Z'];

  const [filterName, setFilterName] = useState('');  

  const [value1, setValue1] = useState(null);
  
  const [value3, setValue3] = useState([]);

  const [value2, setValue2] = useState('');
  const currentYear = new Date().getFullYear();
  const years = [(currentYear - 1).toString(),currentYear.toString(),(currentYear+1).toString()];

  //console.log(years)

  

  const handleButtonClick = () => {
    let month=value1.value
    let year=value2
    let clientList=value3.map(item=>item.ID)

    console.log(month,year,clientList)
  };

    const columns = //clientList
    [
        { id: 'Sno', name: 'Sno' },
        { id: 'EventNo', name: 'Event Number' },
        { id: 'CameraName', name: 'Camera Name' },
        { id: 'EscalationUrl', name: 'Escalation Url' }
    ]

    const values = [
        { EventNo: '123', CameraName: 'test1', EscalationUrl: 'abc.com' },
        { EventNo: '456', CameraName: 'test2', EscalationUrl: 'def.com' },
        { EventNo: '789', CameraName: 'test3', EscalationUrl: 'ghi.com' },
        { EventNo: '101112', CameraName: 'test4', EscalationUrl: 'jkl.com' },
        { EventNo: '131415', CameraName: 'test5', EscalationUrl: 'mno.com' },
        { EventNo: '161718', CameraName: 'test6', EscalationUrl: 'pqr.com' },
        { EventNo: '192021', CameraName: 'test7', EscalationUrl: 'stu.com' },
        { EventNo: '222324', CameraName: 'test8', EscalationUrl: 'vwx.com' },
        { EventNo: '252627', CameraName: 'test9', EscalationUrl: 'yz.com' },
        { EventNo: '282930', CameraName: 'test10', EscalationUrl: 'xyz.com' }
    ];

const [data, setData] = useState([])
const [row,rowChange] = useState([])
const [page,pageChange]=useState(0)
const [rowPerPage,rowPerPageChange]=useState(5)

useEffect(() => {
    setData(values)
}, [])

const handleChangePage = (event,newpage)=>{
    if(newpage===0){
        pageChange(0);
    }
    else{
        pageChange(newpage)
    }
}

const handleRowsPerPage = (e)=>{
    rowPerPageChange(e.target.value)
    pageChange(0)
}

const handleFilterByName = (event) => {
    const pattern=event.target.value.trim()
    setFilterName(pattern);
  };

  useEffect(()=>{
    console.log(filterName)
  },[filterName])

  MonthlyEscalationReport.prototype = {
    numSelected: PropTypes.number,
    filterName: PropTypes.string,
    onFilterName: PropTypes.func,
  }



  return (
    <Grid sx={{ marginLeft: '1rem' }}>
        <Grid container spacing={2} alignItems="center" sx={{marginTop:'0.2rem'}}>
        
            <Grid item xs={3}>
                <Typography variant='subtitle2' component="div">
                Month{' '}
                <Typography
                    variant="subtitle1"
                    component="span"
                    sx={{ color: 'red', display: 'inline' }}
                >
                    *
                </Typography>
                </Typography>

                <Autocomplete
                value={value1}
                onChange={(event, newValue) => {                    
                    setValue1(newValue);
                }}
                options={months}
                getOptionLabel={(option)=>option.name}
                renderInput={(params) => (
                    <TextField
                    {...params}
                    placeholder="Select Month"
                    variant="outlined"
                    />
                )}
                />
            </Grid>
            
            <Grid item xs={3}>
                <Typography variant="subtitle2" component="div">
                Year{' '}
                <Typography
                    variant="subtitle1"
                    component="span"
                    sx={{ color: 'red', display: 'inline' }}
                >
                    *
                </Typography>
                </Typography>
                <Autocomplete
                value={value2}
                onChange={(event, newValue) => {
                    setValue2(newValue);
                }}
                options={years}
                getOptionLabel={(option)=>option}
                renderInput={(params) => (
                    <TextField
                    {...params}
                    placeholder="Select Year"
                    variant="outlined"
                    />
                )}
                />
            </Grid>
            
            <Grid item xs={3}>
                <Typography variant="subtitle2" component="div">
                Client{' '}
                <Typography
                    variant="subtitle1"
                    component="span"
                    sx={{ color: 'red', display: 'inline' }}
                >
                    *
                </Typography>
                </Typography>
                <Autocomplete
                 multiple
                value={value3}
                onChange={(event, newValue) => {
                    setValue3(newValue);
                }}
                options={clientList}
                getOptionLabel={(option)=>option.Name}
                renderInput={(params) => (
                    <TextField
                    {...params}
                    placeholder="Select Client"
                    variant="outlined"
                    />
                )}
                />
            </Grid>
            
            <Grid item xs={3} sx={{marginTop:2}}>
                    <Button variant="contained" onClick={handleButtonClick}>
                    Submit
                    </Button>     
                    <Button variant="contained" sx={{marginLeft:1}}>
                            Export To Excel
                    </Button>               
            </Grid>
        
        </Grid>

        <Grid container spacing={2} sx={{marginTop:2}}>
            <SearchStyle
            value={filterName}
            onChange={handleFilterByName}
            placeholder="Search"
            startAdornment={
                <InputAdornment position="start">
                <Iconify icon="eva:search-fill" sx={{ color: 'text.disabled', width: 20, height: 20 }} />
                </InputAdornment>
            }
            /> 
        </Grid>        
   
        <Grid container spacing={2} alignItems="center" sx={{ marginTop: '1rem' }}>
        <Scrollbar>
          <TableContainer sx={{ minWidth: 800 }}>
            <Table stickyHeader>
                <TableHead>
                            <TableRow sx={{backgroundColor: '#f2f2f2'}}>
                                {columns.map(item => {
                                    return <TableCell key={item.id}>
                                        {item.name}
                                    </TableCell>
                                })}
                            </TableRow>
                </TableHead>
                <TableBody>
                    {data && data
                        .slice(page * rowPerPage, (page * rowPerPage) + rowPerPage)
                        .map((item, index) => {
                        return <TableRow key={item.EventNo}>
                            {columns.map((column, i) => {
                            if (column.id === 'Sno') {
                                return <TableCell key={i}>{page * rowPerPage + index + 1}</TableCell>
                            } else {
                                return <TableCell key={i}>{item[column.id]}</TableCell>
                            }
                            })}
                        </TableRow>
                        })}
                </TableBody>
            </Table>
          </TableContainer>
        </Scrollbar>
        </Grid>

        <Grid>
            <TablePagination
                rowsPerPageOptions={[5,10,25]}
                page={page}
                count={data.length}
                rowsPerPage={rowPerPage}
                component='div'
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleRowsPerPage}
                sx={{ backgroundColor: '#f2f2f2' }}
            />
        </Grid>
    </Grid>
  );
};

export default MonthlyEscalationReport;