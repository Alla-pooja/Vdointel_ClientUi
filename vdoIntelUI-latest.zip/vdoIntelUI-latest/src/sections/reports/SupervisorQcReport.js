import React, { useState,useEffect } from 'react';
import { filter } from 'lodash';
import {
  Grid,
  Box,
  Autocomplete,
  Button,
  TextField,
  Typography,
  TableCell,
  TableRow,
  TableBody,
  Table,
  TableHead,
  TableContainer,TablePagination,OutlinedInput,InputAdornment
} from '@mui/material';
import Scrollbar from 'src/components/Scrollbar';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { renderTimeViewClock } from '@mui/x-date-pickers/timeViewRenderers';
import Iconify from 'src/components/Iconify';
import { styled } from '@mui/material/styles';

const options1 = ['Option 1', 'Option 2', 'Option 3'];
const options2 = ['Option A', 'Option B', 'Option C'];
const options3 = ['Choice X', 'Choice Y', 'Choice Z'];

const SupervisorQcReport = () => {
  const [value1, setValue1] = useState(null);
  const [value2, setValue2] = useState(null);
  const [value3, setValue3] = useState(null);

  const handleButtonClick = () => {
    // handle form submission
    console.log('Dropdown 1 value:', value1);
    console.log('Dropdown 2 value:', value2);
    console.log('Dropdown 3 value:', value3);
  };

    const columns = [
        { id: 'Sno', name: 'Sno' },
        { id: 'SupervisorName', name: 'Supervisor Name' },
        { id: 'Production', name: 'Production' },
        { id: 'QASampling', name: 'QA Sampling' },
        { id: 'Validation', name: 'Validation' },
        { id: 'QAScore', name: 'QAScore(%)' },
        { id: 'Result', name: 'Result' }
    ]

    const values = [
        { SupervisorName: 'SupOne', Production: 123, QASampling: 0, Validation: 0, QAScore: 0, Result: 0 },
        { SupervisorName: 'SupTwo', Production: 456, QASampling: 0, Validation: 0, QAScore: 0, Result: 0 },
        { SupervisorName: 'SupThree', Production: 789, QASampling: 0, Validation: 0, QAScore: 0, Result: 0 },
        { SupervisorName: 'SupFour', Production: 101112, QASampling: 0, Validation: 0, QAScore: 0, Result: 0 },
        { SupervisorName: 'SupFive', Production: 131415, QASampling: 0, Validation: 0, QAScore: 0, Result: 0 },
        { SupervisorName: 'SupSix', Production: 161718, QASampling: 0, Validation: 0, QAScore: 0, Result: 0 },
        { SupervisorName: 'SupSeven', Production: 192021, QASampling: 0, Validation: 0, QAScore: 0, Result: 0 },
        { SupervisorName: 'SupEight', Production: 222324, QASampling: 0, Validation: 0, QAScore: 0, Result: 0 },
        { SupervisorName: 'SupNine', Production: 252627, QASampling: 0, Validation: 0, QAScore: 0, Result: 0 },
        { SupervisorName: 'SupTen', Production: 282930, QASampling: 0, Validation: 0, QAScore: 0, Result: 0 }
    ];

const [data, setData] = useState([])
const [row,rowChange] = useState([])
const [page,pageChange]=useState(0)
const [rowPerPage,rowPerPageChange]=useState(5)

useEffect(() => {
    setData(values)
}, [])

const handleChangePage = (event,newpage)=>{
    pageChange(newpage)
}

const handleRowsPerPage = (e)=>{
    rowPerPageChange(e.target.value)
    pageChange(0)
}

const [filterName, setFilterName] = useState('');  
const handleFilterByName = (event) => {
    const pattern=event.target.value.trim()
    setFilterName(pattern);
  };

  
const SearchStyle = styled(OutlinedInput)(({ theme }) => ({
    width: 240,
    marginLeft: 15,
    transition: theme.transitions.create(['box-shadow', 'width'], {
      easing: theme.transitions.easing.easeInOut,
      duration: theme.transitions.duration.shorter,
    }),
    '&.Mui-focused': { width: 320, boxShadow: theme.customShadows.z8 },
    '& fieldset': {
      borderWidth: `1px !important`,
      borderColor: `${theme.palette.grey[500_32]} !important`,
    },
  }));


const [startDate, setStartDate] = useState(new Date());

  return (
    <Grid sx={{ marginLeft: '1rem' }}>
        <Grid container spacing={2} alignItems="center" sx={{marginTop:'0.2rem'}}>
        
            <Grid item xs={3}>
                <Typography variant='subtitle2' component="div">
                From Date{' '}
                <Typography
                    variant="subtitle1"
                    component="span"
                    sx={{ color: 'red', display: 'inline' }}
                >
                    *
                </Typography>
                </Typography>

                <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DemoContainer components={['DateTimePicker', 'DateTimePicker']}>
                        <DateTimePicker
                        viewRenderers={{
                            hours: renderTimeViewClock,
                            minutes: renderTimeViewClock,
                            seconds: renderTimeViewClock,
                        }}
                        format="YYYY-MM-DD HH:mm"
                        // value={startDate}
                        // onChange={(newdate)=>setStartDate(newdate)}
                        />
                    </DemoContainer>
                </LocalizationProvider>

            </Grid>
            
            <Grid item xs={3}>
                <Typography variant="subtitle2" component="div">
                To Date{' '}
                <Typography
                    variant="subtitle1"
                    component="span"
                    sx={{ color: 'red', display: 'inline' }}
                >
                    *
                </Typography>
                </Typography>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DemoContainer components={['DateTimePicker', 'DateTimePicker']}>
                        <DateTimePicker
                        viewRenderers={{
                            hours: renderTimeViewClock,
                            minutes: renderTimeViewClock,
                            seconds: renderTimeViewClock,
                        }}
                        format="YYYY-MM-DD HH:mm"
                        // value={startDate}
                        // onChange={(newdate)=>setStartDate(newdate)}
                        />
                    </DemoContainer>
                </LocalizationProvider>
            </Grid>
        
            <Grid item xs={3} sx={{marginTop:3}}>
                <Button variant="contained" onClick={handleButtonClick}>
                Submit
                </Button>
                <Button variant="contained" sx={{marginLeft:1}}>
                        Export To Excel
                </Button>
            </Grid>
        
        </Grid>

        <Grid container spacing={2} sx={{marginTop:2}}>
                <SearchStyle
                value={filterName}
                onChange={handleFilterByName}
                placeholder="Search"
                startAdornment={
                    <InputAdornment position="start">
                    <Iconify icon="eva:search-fill" sx={{ color: 'text.disabled', width: 20, height: 20 }} />
                    </InputAdornment>
                }
                /> 
        </Grid>        
   
        <Grid container spacing={2} alignItems="center" sx={{ marginTop: '1rem' }}>
        <Scrollbar>
          <TableContainer sx={{ minWidth: 800 }}>
            <Table stickyHeader>
                <TableHead>
                            <TableRow sx={{backgroundColor: '#f2f2f2'}}>
                                {columns.map(item => {
                                    return <TableCell key={item.id}>
                                        {item.name}
                                    </TableCell>
                                })}
                            </TableRow>
                </TableHead>
                <TableBody>
                        {data && data
                                .slice(page * rowPerPage, (page * rowPerPage) + rowPerPage)
                                .map((item, index) => {
                            return <TableRow key={`${item.EventNo}-${index}`}>
                                {columns.map((column, i) => {
                                    if (column.id === 'Sno') {
                                        return <TableCell key={i}>{page * rowPerPage + index + 1}</TableCell>
                                    } else {
                                        return <TableCell key={i}>{item[column.id]}</TableCell>
                                    }
                                })}
                            </TableRow>
                        })}
                </TableBody>
            </Table>
          </TableContainer>
        </Scrollbar>
      </Grid>

        <Grid>
            <TablePagination
                rowsPerPageOptions={[5,10,25]}
                page={page}
                count={data.length}
                rowsPerPage={rowPerPage}
                component='div'
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleRowsPerPage}
                sx={{ backgroundColor: '#f2f2f2' }}
            />
        </Grid>
    </Grid>
  );
};

export default SupervisorQcReport;