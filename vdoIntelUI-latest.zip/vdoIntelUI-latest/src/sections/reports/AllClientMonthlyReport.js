import React, { useState,useEffect } from 'react';
import Iconify from 'src/components/Iconify';
import {
  Grid,
  Box,
  Autocomplete,
  Button,
  TextField,
  Typography,
  TableCell,
  TableRow,
  TableBody,
  Table,
  TableHead,
  TableContainer,TablePagination,OutlinedInput,InputAdornment
} from '@mui/material';
import Scrollbar from 'src/components/Scrollbar';
import * as XLSX from 'xlsx';
import { styled } from '@mui/material/styles';
import { getAllclientMonReport } from 'src/api/reports';

const months = [
  { name: 'January', value: '1' },
  { name: 'February', value: '2' },
  { name: 'March', value: '3' },
  { name: 'April', value: '4' },
  { name: 'May', value: '5' },
  { name: 'June', value: '6' },
  { name: 'July', value: '7' },
  { name: 'August', value: '8' },
  { name: 'September', value: '9' },
  { name: 'October', value: '10' },
  { name: 'November', value: '11' },
  { name: 'December', value: '12' }
];
const currentYear = new Date().getFullYear();
const years = [currentYear - 1,currentYear,currentYear + 1];
const options3 = ['Choice X', 'Choice Y', 'Choice Z'];

const AllClientMonthlyReport = () => {
  const [value1, setValue1] = useState(null);
  const [value2, setValue2] = useState(null);
  const [allClientMonReport, setAllClientMonRep] = useState([]);
  const [data, setData] = useState([])
  const [row,rowChange] = useState([])
  const [page,pageChange]=useState(0)
  const [rowPerPage,rowPerPageChange]=useState(5)


  const handleButtonClick = () => {
    // handle form submission
    setData('');
    console.log('Dropdown 1 value:', value1.value);
    console.log('Dropdown 2 value:', value2);
    // console.log('Dropdown 3 value:', value3);

    getAllclientMonReport(value1.value, value2, (response) => {
      if (response.status === 200) {
        setAllClientMonRep(response.data)
        console.log('All C M Data',response.data);
      } 
    });

    // getSavedAnalytics(selectedClients, (response) => {
    //   if (response.status === 200) {
    //     const managedData = manageAnalyticsSettings(response.data);
    //     setAnalyticsSettings({ ...managedData });
    //   }
    // });
  };

    const columns = [
        { id: 'Sno', name: 'Sno' },
        { id: 'ClientName', name: 'Client Name' },
        { id: 'TotalCameras', name: 'Total Cameras' },
        { id: 'TotalEvents', name: 'Total Events' },
        { id: 'TrueEvents', name: 'True Events' },
        { id: 'FalseEvents', name: 'False Events' },
        { id: 'EscalatedEvents', name: 'Escalated Events' }
    ]

    // const values1 = [
    //     { ClientName: 'ClientOne', TotalCameras: 123, TotalEvents: 0, TrueEvents: 0, FalseEvents: 0, EscalatedEvents: 0 },
    //     { ClientName: 'ClientTwo', TotalCameras: 456, TotalEvents: 0, TrueEvents: 0, FalseEvents: 0, EscalatedEvents: 0 },
    //     { ClientName: 'ClientThree', TotalCameras: 789, TotalEvents: 0, TrueEvents: 0, FalseEvents: 0, EscalatedEvents: 0 },
    //     { ClientName: 'ClientFour', TotalCameras: 101112, TotalEvents: 0, TrueEvents: 0, FalseEvents: 0, EscalatedEvents: 0 },
    //     { ClientName: 'ClientFive', TotalCameras: 131415, TotalEvents: 0, TrueEvents: 0, FalseEvents: 0, EscalatedEvents: 0 },
    //     { ClientName: 'ClientSix', TotalCameras: 161718, TotalEvents: 0, TrueEvents: 0, FalseEvents: 0, EscalatedEvents: 0 },
    //     { ClientName: 'ClientSeven', TotalCameras: 192021, TotalEvents: 0, TrueEvents: 0, FalseEvents: 0, EscalatedEvents: 0 },
    //     { ClientName: 'ClientEight', TotalCameras: 222324, TotalEvents: 0, TrueEvents: 0, FalseEvents: 0, EscalatedEvents: 0 },
    //     { ClientName: 'ClientNine', TotalCameras: 252627, TotalEvents: 0, TrueEvents: 0, FalseEvents: 0, EscalatedEvents: 0 },
    //     { ClientName: 'ClientTen', TotalCameras: 282930, TotalEvents: 0, TrueEvents: 0, FalseEvents: 0, EscalatedEvents: 0 }
    // ];


    const values = allClientMonReport.map(client => ({
      ClientName: client.Name,
      TotalCameras: client.cameras,
      TotalEvents: client.total_event_count,
      TrueEvents: client.true_event_count,
      FalseEvents: client.false_event_count,
      EscalatedEvents: client.escalated_event_count
  }));




useEffect(() => {
    setData(values)
}, [])

const handleChangePage = (event,newpage)=>{
    pageChange(newpage)
}
const [filterName, setFilterName] = useState('');  
const handleFilterByName = (event) => {
    const pattern=event.target.value.trim()
    setFilterName(pattern);
  };

  
const SearchStyle = styled(OutlinedInput)(({ theme }) => ({
    width: 240,
    marginLeft: 15,
    transition: theme.transitions.create(['box-shadow', 'width'], {
      easing: theme.transitions.easing.easeInOut,
      duration: theme.transitions.duration.shorter,
    }),
    '&.Mui-focused': { width: 320, boxShadow: theme.customShadows.z8 },
    '& fieldset': {
      borderWidth: `1px !important`,
      borderColor: `${theme.palette.grey[500_32]} !important`,
    },
  }));

const handleRowsPerPage = (e)=>{
    rowPerPageChange(e.target.value)
    pageChange(0)
}

const downloadExcel = () => {
    debugger;
    if (values && values.length > 0) {
        const sheetName = 'All Clients Monthy Report';
        const headers = Object.keys(values);
        const data = [headers, ...values.map(item => headers.map(key => item[key]))];
    
        const ws = XLSX.utils.aoa_to_sheet(data);
        const filename = sheetName + '.xlsx';
    
        const maxColumnWidths = {};
        headers.forEach(header => {
          maxColumnWidths[header] = Math.max(
            20,
            ...data.map(row => (row[header] || '').toString().length)
          );
        });
        const columnWidths = headers.map(header => ({
          wch: maxColumnWidths[header]
        }));
    
        ws['!cols'] = columnWidths;
    
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, sheetName || 'Sheet 1');
    
        XLSX.writeFile(wb, filename);
      } else {
        alert('No data to Export.');
        return;
      }

    // const csvData = [
    //   header,
    //   ...data.map(item => columns.map(column => item[column.id]).join(','))
    // ].join('\n');
  
    // const csvBlob = new Blob([csvData], { type: 'text/csv' });
    // const csvUrl = window.URL.createObjectURL(csvBlob);
  
    // const link = document.createElement('a');
    // link.href = csvUrl;
    // link.setAttribute('download', 'client_report.csv');
    // document.body.appendChild(link);
    // link.click();
    // document.body.removeChild(link);
  
    // window.URL.revokeObjectURL(csvUrl);
  };


  return (
    <Grid sx={{ marginLeft: '1rem' }}>
        <Grid container spacing={2} alignItems="center" sx={{marginTop:'0.2rem'}}>
            <Grid item xs={3}>
                <Typography variant='subtitle2' component="div">
                Month{' '}
                <Typography
                    variant="subtitle1"
                    component="span"
                    sx={{ color: 'red', display: 'inline' }}
                >
                    *
                </Typography>
                </Typography>
                <Autocomplete
                    value={value1}
                    onChange={(event, newValue) => {
                        setValue1(newValue);
                    }}
                    options={months}
                    getOptionLabel={(option) => option.name} // Display month names
                    getOptionSelected={(option, value) => option.name === value.value} // Ensure proper comparison for selection
                    renderInput={(params) => (
                        <TextField
                            {...params}
                            placeholder="Select Month"
                            variant="outlined"
                        />
                    )}
                />

            </Grid>
            <Grid item xs={3}>
                <Typography variant="subtitle2" component="div">
                Year{' '}
                <Typography
                    variant="subtitle1"
                    component="span"
                    sx={{ color: 'red', display: 'inline' }}
                >
                    *
                </Typography>
                </Typography>
                <Autocomplete
                value={value2}
                onChange={(event, newValue) => {
                    setValue2(newValue);
                }}
                options={years}
                renderInput={(params) => (
                    <TextField
                    {...params}
                    placeholder="Select Year"
                    variant="outlined"
                    />
                )}
                />
            </Grid>
            <Grid item xs={3} sx={{marginTop:2}}>
                <Button variant="contained" onClick={handleButtonClick}>
                Submit
                </Button>
                <Button variant="contained" onClick={downloadExcel} sx={{marginLeft:1}}>
                        Export To Excel
                </Button>
            </Grid>
        </Grid>

        <Grid container spacing={2} sx={{marginTop:2}}>
            <SearchStyle
                value={filterName}
                onChange={handleFilterByName}
                placeholder="Search"
                startAdornment={
                    <InputAdornment position="start">
                    <Iconify icon="eva:search-fill" sx={{ color: 'text.disabled', width: 20, height: 20 }} />
                    </InputAdornment>
                }
                /> 
        </Grid>        
   
        <Grid container spacing={2} alignItems="center" sx={{ marginTop: '1rem' }}>
        <Scrollbar>
          <TableContainer sx={{ minWidth: 800 }}> 
            <Table stickyHeader>
                <TableHead>
                            <TableRow sx={{backgroundColor: '#f2f2f2'}}>
                                {columns.map(item => {
                                    return <TableCell key={item.id}>
                                        {item.name}
                                    </TableCell>
                                })}
                            </TableRow>
                </TableHead>
                <TableBody>
                        {data && data
                                .slice(page * rowPerPage, (page * rowPerPage) + rowPerPage)
                                .map((item, index) => {
                            return <TableRow key={`${item.EventNo}-${index}`}>
                                {columns.map((column, i) => {
                                    if (column.id === 'Sno') {
                                        return <TableCell key={i}>{page * rowPerPage + index + 1}</TableCell>
                                    } else {
                                        return <TableCell key={i}>{item[column.id]}</TableCell>
                                    }
                                })}
                            </TableRow>
                        })}
                </TableBody>
            </Table>
          </TableContainer>
        </Scrollbar>
      </Grid>

        <Grid>
            <TablePagination
                rowsPerPageOptions={[5,10,25]}
                page={page}
                count={data.length}
                rowsPerPage={rowPerPage}
                component='div'
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleRowsPerPage}
                sx={{ backgroundColor: '#f2f2f2' }}
            />
        </Grid>
    </Grid>
  );
};

export default AllClientMonthlyReport;