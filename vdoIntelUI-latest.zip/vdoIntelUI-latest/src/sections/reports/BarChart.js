import React from 'react'
import {
    ArgumentAxis,
    ValueAxis,
    Chart,
    BarSeries,
} from "@devexpress/dx-react-chart-material-ui";

export default function BarChart() {
    const data = [
        { argument: "Monday", value: 30 },
        { argument: "Tuesday", value: 20 },
        { argument: "Wednesday", value: 10 },
        { argument: "Thursday", value: 50 },
        { argument: "Friday", value: 60 },
    ];
    return (
            <Chart data={data}>
                <ArgumentAxis />
                <ValueAxis />
 
                <BarSeries
                    valueField="value"
                    argumentField="argument"
                />
            </Chart>
    );
}