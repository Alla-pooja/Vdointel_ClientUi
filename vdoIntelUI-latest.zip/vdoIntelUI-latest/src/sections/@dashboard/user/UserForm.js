import * as Yup from 'yup';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useFormik, Form, FormikProvider } from 'formik';
// material
import {
  Stack,
  TextField,
  IconButton,
  InputAdornment,
  Alert
} from '@mui/material';
import { LoadingButton } from '@mui/lab';
// component
import PropTypes from 'prop-types';
import Iconify from '../../../components/Iconify';
import axios from '../../../axios'

import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';

import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

// ----------------------------------------------------------------------

export default function UserFrom({ isOpen, setOpen }) {



  const [fullWidth, setFullWidth] = useState(true);
  const [maxWidth, setMaxWidth] = useState('md');

  // const handleClickOpen = () => {
  //     setOpen(true);
  // };

  const handleClose = () => {
    setOpen(false);
  };

  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [isError, setErrorMsg] = useState({ status: false, msg: "" })

  const LoginSchema = Yup.object().shape({
    username: Yup.string().required('Username is required'),
    password: Yup.string().required('Password is required')
  });

  const jsonToParam = (data) => {
    return Object.keys(data).map(function (k) {
      return encodeURIComponent(k) + '=' + encodeURIComponent(data[k])
    }).join('&')
  }

  const formik = useFormik({
    initialValues: {
      username: '',
      password: '',
      grant_type: 'password'
    },
    validationSchema: LoginSchema,
    onSubmit: () => {
      setErrorMsg((er) => er.status = false)
      axios({
        method: 'post',
        url: '/token',
        data: jsonToParam(values),
        validateStatus: function (status) {
          return status >= 200 || status === 400;
        }
      }).then(function (response) {
        setSubmitting(false)
        if (response.status === 200 || response.status === 201) {

          navigate('/', { replace: true })
        } else
          setErrorMsg({ status: true, msg: (response.data.error_description ?? 'The user name or password is incorrect') })
      })

    }
  });

  const { errors, touched, values, isSubmitting, handleSubmit, getFieldProps, setSubmitting } = formik;

  const handleShowPassword = () => {
    setShowPassword((show) => !show);
  };

  return (


    <Dialog
      fullWidth={fullWidth}
      maxWidth={maxWidth}
      open={isOpen}
      onClose={handleClose}
    >
      <DialogTitle>Optional sizes</DialogTitle>
      <DialogContent>
        <DialogContentText>
          You can set my maximum width and whether to adapt or not.
        </DialogContentText>
        



          <FormikProvider value={formik}>
            {(isError.status) && (
              <Alert severity="error" sx={{ mb: 3 }}>{isError.msg}</Alert>
            )}
            <Form autoComplete="off" noValidate onSubmit={handleSubmit}>
              <Stack spacing={3} sx={{ mb: 3 }}>
                <TextField
                  fullWidth
                  autoComplete="username"
                  type="text"
                  label="Username"
                  {...getFieldProps('username')}
                  error={Boolean(touched.username && errors.username)}
                  helperText={touched.username && errors.username}
                />

                <TextField
                  fullWidth
                  autoComplete="current-password"
                  type={showPassword ? 'text' : 'password'}
                  label="Password"
                  {...getFieldProps('password')}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton onClick={handleShowPassword} edge="end">
                          <Iconify icon={showPassword ? 'eva:eye-fill' : 'eva:eye-off-fill'} />
                        </IconButton>
                      </InputAdornment>
                    )
                  }}
                  error={Boolean(touched.password && errors.password)}
                  helperText={touched.password && errors.password}
                />
              </Stack>

              <LoadingButton
                fullWidth
                size="large"
                type="submit"
                variant="contained"
                loading={isSubmitting}
              >
                Submit
              </LoadingButton>
            </Form>
          </FormikProvider>


    
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Close</Button>
      </DialogActions>
    </Dialog>





  );
}

UserFrom.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  setOpen: PropTypes.func.isRequired
}