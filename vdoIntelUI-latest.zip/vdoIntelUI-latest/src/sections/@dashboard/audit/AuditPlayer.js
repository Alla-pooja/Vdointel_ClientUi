import {
    Box,
    Typography,
    Stack,
    Chip,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    IconButton,
    Avatar
} from "@mui/material";

import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';

import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';

import Iconify from '../../../components/Iconify';
import useVideoPlayer from "src/hooks/useVideoPlayer";
import { useEffect, useRef, useState} from 'react'
import PropTypes from 'prop-types';

import { fDateTime } from "src/utils/formatTime"

import { LoadingButton } from '@mui/lab';
import { handleResponse } from "src/utils/responseHandler"
import axios from 'src/axios'
import { getURL } from 'src/utils/config';




const handleVideoPlay = (stream) => {
    try {
        window.JSBridge.showMessageInNative(stream)
    } catch (e) {
        console.info('Need to go on web view')
    }
}

const isWebView = () => {
    // Get the user agent string
    var userAgent = navigator.userAgent.toLowerCase();
    
    // Check if the user agent contains "wv" or "webview" (common indicators of a web view)
    return userAgent.includes("wv") || userAgent.includes("webview");    
      
}

export default function AuditPlayer({ player, setPlayer, updateToClient, isEscalating }) {
    const videoElement = useRef(null)
    const [fullWidth, setFullWidth] = useState(true);
    const [maxWidth, setMaxWidth] = useState('md');


    const [isSubmitting, setIsSubmitting] = useState(false)
    const sendMail = () => {
        setIsSubmitting(true)
        axios({
            method: 'get',
            url: getURL(`client-info/send-client-mail-consolidated?devicename=${player.devicename}&detectedtype=${player.DetectedType}&videourl=${player.VideoUrl}`),
            validateStatus: (status) => handleResponse(status),
        }).then(function (response) {
            setIsSubmitting(false)
            if (response.status === 200) {
            window.alert("Email has been sent successfully.")
            } else {
            window.alert("Something went wrong. Please try again later")
            }
        })
    }

    // const [isOpen, setOpen] = useState(false)
    const handleClose = () => {
        // setOpen(false)
        const isOpen = false
        setPlayer((plyr) => {return {...plyr, isOpen}})
      };
    
    // const [player, setPlayer] = useState(initValues)
    const {
        playerState,
        togglePlay,
        handleOnTimeUpdate,
        handleVideoSpeed,
        handlePause,
        handlePlay,
        handleInitPlay
    } = useVideoPlayer(videoElement);


    useEffect(() => {
        if (player.VideoUrl)
            handleInitPlay()
    }, [player.VideoUrl])


    return (

        <Dialog
            fullWidth={fullWidth}
            maxWidth={maxWidth}
            open={player.isOpen}
            onClose={handleClose}
        >
            <DialogTitle>
                <Typography variant="b">Audit ID {player.Id}</Typography>
                <Typography color="gray">{player.DeviceName}</Typography>                
            </DialogTitle>
            <DialogContent>
                {/* <DialogContentText>
                    You can set my maximum width and whether to adapt or not.
                </DialogContentText> */}
                <Box>
                    {isWebView() ? (
                        <Stack direction="row"
                        justifyContent="center"
                        alignItems="center"
                        spacing={2} onClick={() => handleVideoPlay(player.VideoUrl)} style={{ background: 'linear-gradient(to top, rgb(6, 6, 6), 20%, rgb(51 51 51))', minHeight: 180}}>
                         <IconButton sx={{ color: "white" }}>
                            <Iconify sx={{ height: 40, width: 40 }} icon={"eva:play-circle-outline"} />
                         </IconButton>
                         </Stack>
                    ): (
                        <Box style={{ background: 'linear-gradient(to top, rgb(6, 6, 6), 20%, rgb(51 51 51))', maxHeight: 403}}>
                            <video
                                src={player.VideoUrl}
                                controls
                                ref={videoElement}
                                // onTimeUpdate={handleOnTimeUpdate}
                                onPause={handlePause}
                                onPlay={handlePlay}
                                style={{ maxHeight: 403, width: '100%', display: player.display }} />
                        </Box>
                    )}
                    
                    <Stack direction="row"
                        justifyContent="flex-start"
                        alignItems="flex-start"
                        spacing={2} sx={{ my: 2 }}>
                        {/* <Box>
                            <Chip
                                disabled={!player.src}
                                label={`Video ${playerState.playStatus}`}
                                color={playerState.isPlaying ? "primary" : "error"}
                                variant="outlined"
                                size="small" />
                            
                        </Box> */}
                        <FormControl>
                            <InputLabel id="video-simple-select-label">Speed</InputLabel>
                            <Select
                                labelId="video-simple-select-label"
                                id="video-simple-select"
                                label="Speed"
                                value={playerState.speed}
                                onChange={(e) => handleVideoSpeed(e)}
                                disabled={!player.VideoUrl}
                            >
                                <MenuItem value={1}>1x</MenuItem>
                                <MenuItem value={2}>2x</MenuItem>
                                <MenuItem value={3}>3x</MenuItem>
                                <MenuItem value={4}>4x</MenuItem>
                                <MenuItem value={5}>5x</MenuItem>
                            </Select>
                        </FormControl>
                        <IconButton aria-label="refresh" color="success" onClick={togglePlay} disabled={!player.VideoUrl}>
                            {!playerState.isPlaying ? (
                                <Iconify disabled={!player.VideoUrl} icon="bi:play-circle-fill" sx={{ height: 34, width: 34 }} />
                            ) : (
                                <Iconify icon="bi:pause-circle-fill" sx={{ height: 34, width: 34 }} />
                            )}
                        </IconButton>
                        {localStorage.getItem('ID') === '2' && (
                            <Button color="error" variant="outlined" onClick={() => updateToClient(`'${player.Id}'`)}>True Event</Button>
                        )}
                    </Stack>

                    <Box>
                        {(player.DetectedType) && [...player.DetectedType.split(',')].map((value, key) => (
                        <Chip sx={{ textTransform: "capitalize", mr: 1, mb: 1 }} key={key} avatar={<Avatar>{value.charAt(0).toUpperCase() || ''}</Avatar>} label={value} />
                        ))}
                    </Box>     

                    {Number(localStorage.getItem("client_id")) === 831 && (
                        <LoadingButton 
                        sx={{ mt: 2}}
                        fullWidth
                        variant="contained"
                        loading={isSubmitting}
                        onClick={sendMail}
                        >
                        Send Mail
                        </LoadingButton>
                        )}                   
                    
                </Box>

            </DialogContent>
            <Stack direction="row"
                justifyContent="space-between"
                alignItems="center"
                spacing={2}
                sx={{ px: 2, py: 1 }}
                >
                {player.CreatedOn && (<Typography sx={{pl:1}} color={"gray"}>{ fDateTime(player.CreatedOn)}</Typography>) }               
                <Button onClick={handleClose}>Close</Button>                
            </Stack>
        </Dialog>
    )
}

AuditPlayer.propTypes = {
    player: PropTypes.object.isRequired,
    setPlayer: PropTypes.func.isRequired
}