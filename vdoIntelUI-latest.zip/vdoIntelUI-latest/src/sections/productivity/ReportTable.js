import { filter } from 'lodash';
import { sentenceCase } from 'change-case';
import { useEffect, useState } from 'react';
import { Link as RouterLink } from 'react-router-dom';
// material
import {
  Table,
  Stack,
  Avatar,
  TableRow,
  TableBody,
  TableCell,
  Typography,
  TableContainer,
  TablePagination,
  LinearProgress,
  Box,
  IconButton,
  Link
} from '@mui/material';
// components
import Scrollbar from '../../components/Scrollbar';
import Iconify from '../../components/Iconify';
import SearchNotFound from '../../components/SearchNotFound';
import { UserListHead, UserListToolbar} from './table';
// mock
import USERLIST from '../../_mock/user';
import { DetailsBox } from './modules';
import { useTheme } from '@mui/material/styles';

// ----------------------------------------------------------------------

const TABLE_HEAD = [
  { id: 'sno', label: 'S No', alignRight: false },
  { id: 'name', label: 'Name', alignRight: false },
  { id: 'company', label: 'Shift', alignRight: false },
  { id: 'role', label: 'Present Duration', alignRight: false },
  { id: 'isVerified', label: 'Absent Duration', alignRight: false },
  { id: 'sleep', label: 'Sleeping Duration', alignRight: false },
  { id: 'status', label: 'Progress', alignRight: false },
  // { id: '' },
];

// ----------------------------------------------------------------------

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  if (query) {
    return filter(array, (_user) => _user.name.toLowerCase().indexOf(query.toLowerCase()) !== -1);
  }
  return stabilizedThis.map((el) => el[0]);
}

function LinearProgressWithLabel(props) {
    return (
      <Box sx={{ display: 'flex', alignItems: 'center' }}>
        <Box sx={{ width: '100%', mr: 1 }}>
          <LinearProgress variant="determinate" {...props} />
        </Box>
        <Box sx={{ minWidth: 35 }}>
          <Typography variant="body2" color="text.secondary">{`${Math.round(
            props.value,
          )}%`}</Typography>
        </Box>
      </Box>
    );
  }

export default function ReportTable({ filterData, reportData }) {
  const [page, setPage] = useState(0);

  const [order, setOrder] = useState('asc');

  const [selected, setSelected] = useState([]);

  const [orderBy, setOrderBy] = useState('name');

  const [filterName, setFilterName] = useState('');

  const [rowsPerPage, setRowsPerPage] = useState(5);

  const [details, setDetails] = useState({ open: false, data: {}});

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelecteds = reportData.map((n) => n.name);
      setSelected(newSelecteds);
      return;
    }
    setSelected([]);
  };

  const handleClick = (event, name) => {
    const selectedIndex = selected.indexOf(name);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, name);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(selected.slice(0, selectedIndex), selected.slice(selectedIndex + 1));
    }
    setSelected(newSelected);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleFilterByName = (event) => {
    setFilterName(event.target.value);
  };

  const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - reportData.length) : 0;

  const filteredUsers = applySortFilter(reportData, getComparator(order, orderBy), filterName);

  const isUserNotFound = filteredUsers.length === 0;



  function handleDialog (value=false, data={}, detailsType="present") {
    setDetails({...details, open:value, data: data, detailsType: detailsType})
  }

  const theme = useTheme()

  
  
  return (

        <>
          <DetailsBox dialogHandler={handleDialog} dialogConfig={details}/>
          <UserListToolbar numSelected={selected.length} filterName={filterName} onFilterName={handleFilterByName} />

          <Scrollbar>
            <TableContainer sx={{ minWidth: 800, borderRadius: 0 }}>
              <Table>
                <UserListHead
                  order={order}
                  orderBy={orderBy}
                  headLabel={TABLE_HEAD}
                  rowCount={reportData.length}
                  numSelected={selected.length}
                  onRequestSort={handleRequestSort}
                  onSelectAllClick={handleSelectAllClick}
                />
                <TableBody>
                  {filteredUsers.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, idx) => {
                    const { absent_duration, securityname, shiftname, short_image, present_duration, progress_percent } = row;
                    const isItemSelected = selected.indexOf(securityname) !== -1;
                    const isDisplay = filterData.type === 'all' || 
                    (filterData.type.toLowerCase() === 'low' && Number(progress_percent) < 80) ||
                    (filterData.type.toLowerCase() === 'medium' && Number(progress_percent) >= 80 && Number(progress_percent) < 90) ||
                    (filterData.type.toLowerCase() === 'high' && Number(progress_percent) >= 90)
                    // console.log(isDisplay, filterData.type)
                    return isDisplay && (
                      <TableRow
                        hover
                        key={idx}
                        tabIndex={-1}
                        role="checkbox"
                        selected={isItemSelected}
                        aria-checked={isItemSelected}
                        sx={{ backgroundColor: Number(progress_percent) > 90 ? 'auto': (Number(progress_percent) > 80 ? theme.palette.warning.lighter: theme.palette.error.lighter) }}
                      >
                        <TableCell>{idx+1}</TableCell>
                        <TableCell component="th" scope="row" padding="none">
                          <Stack direction="row" alignItems="center" spacing={2}>
                            <Avatar alt={securityname} src={short_image} />
                            <Typography variant="subtitle2" noWrap>
                              {securityname}
                            </Typography>
                          </Stack>
                        </TableCell>
                        <TableCell align="left">{shiftname}</TableCell>
                        <TableCell align="left"><Link onClick={() => handleDialog(true, row)}>{present_duration}</Link></TableCell>
                        <TableCell align="left"><Link onClick={() => handleDialog(true, row, 'absent')}>{absent_duration}</Link></TableCell>
                        <TableCell align="left"><Link>00:00:00</Link></TableCell>
                        <TableCell align="left">
                            <LinearProgressWithLabel value={Number(progress_percent)} color={Number(progress_percent) > 90 ? 'success': (Number(progress_percent) > 80 ? 'warning': 'error')} />
                        </TableCell>

                        {/* <TableCell align="right">
                          <IconButton onClick={() => handleDialog(true, row)}>
                            <Iconify icon="eva:alert-circle-outline" width={20} height={20} />
                          </IconButton>                          
                        </TableCell> */}
                      </TableRow>
                    );
                  })}
                  {emptyRows > 0 && (
                    <TableRow style={{ height: 53 * emptyRows }}>
                      <TableCell colSpan={6} />
                    </TableRow>
                  )}
                </TableBody>

                {isUserNotFound && (
                  <TableBody>
                    <TableRow>
                      <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                        <SearchNotFound searchQuery={filterName} />
                      </TableCell>
                    </TableRow>
                  </TableBody>
                )}
              </Table>
            </TableContainer>
          </Scrollbar>

          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={reportData.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </>
  );
}
