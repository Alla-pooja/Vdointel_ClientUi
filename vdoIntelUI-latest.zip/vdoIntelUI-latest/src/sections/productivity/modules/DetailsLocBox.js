import {
    Dialog,
    DialogContent,
    DialogTitle,
    Grid,
    Box,
    Typography,
    LinearProgress,
    Button,
    Table,
    TableHead,
    TableCell,
    TableBody,
    TableRow,
    DialogActions,
    Divider,
    IconButton,
    TableContainer
} from "@mui/material";
import { useState } from "react";
import Iconify from "src/components/Iconify";


function LinearProgressWithLabel(props) {
    return (
      <Box sx={{ display: 'flex', alignItems: 'center' }}>
        <Box sx={{ width: '100%', mr: 1 }}>
          <LinearProgress variant="determinate" {...props} />
        </Box>
        <Box sx={{ minWidth: 35 }}>
          <Typography variant="body2" color="text.secondary">{`${Math.round(
            props.value,
          )}%`}</Typography>
        </Box>
      </Box>
    );
  }

export default function DetailsLocBox({dialogHandler, dialogConfig}){
    const [ video, setVideo ] = useState({open: false, url: null})
    const handleVideo = (isOpen, url=null) => {
        if (!isOpen) {
            setVideo({...video, open: false})
        } else {
            setVideo({...video, open: true, url: url})
        }
    }
    // absent_duration, details, securityname, shiftname, short_image, snapshoturl, present_duration, progress_percent
    const progress_percent = Number(dialogConfig.data.hasOwnProperty('progress_percent') ? dialogConfig.data.progress_percent: 0)
    const details = dialogConfig.detailsType === 'present' ? (dialogConfig.data.hasOwnProperty('details') ? dialogConfig.data.details: []) : dialogConfig.data.hasOwnProperty('absent_details') ? dialogConfig.data.absent_details: []
    const total_duration = dialogConfig.detailsType === 'present' ? (dialogConfig.data.hasOwnProperty('present_duration') ? dialogConfig.data.present_duration: []) : dialogConfig.data.hasOwnProperty('absent_duration') ? dialogConfig.data.absent_duration: []
    // console.log(dialogConfig.data)
    console.log(dialogConfig.detailsType)
    return (
        <Dialog onClose={dialogHandler} open={dialogConfig.open} fullWidth={true}
        maxWidth={'sm'}>
            <DialogContent sx={{p: 0}}>
                {!video.open ? (<>               
                <Box width={"100%"} sx ={{p: 2}}>
                    <Typography variant="h6">{dialogConfig.data.hasOwnProperty('locationname') ? dialogConfig.data.locationname: ''}</Typography>      
                    <Typography color={"gray"}>{total_duration}</Typography>                      
                    
                    {dialogConfig.detailsType === 'present' && <LinearProgressWithLabel value={progress_percent} color={progress_percent > 90 ? 'success': (progress_percent > 80 ? 'warning': 'error')} />}                          
                </Box>
                {/* <Divider/> */}
                <TableContainer sx={{ maxHeight: 340 }}>
                    <Table stickyHeader aria-label="sticky table" sx={{mt: 2}}>
                        <TableHead>
                            <TableRow>
                                {dialogConfig.type === 'location' && <TableCell>Camera</TableCell>}
                                <TableCell>Emp Name</TableCell>
                                <TableCell>From Time</TableCell>
                                <TableCell>To Time</TableCell>
                                <TableCell>Duration</TableCell>
                                <TableCell>Video</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {details.map((row, idx) => {
                                const {cameraname, duration, fromtime, totime, securityname, videourl} = row
                                return (
                                    <TableRow key={idx}>
                                        {dialogConfig.type === 'location' && <TableCell>{cameraname}</TableCell>}
                                        <TableCell>{securityname}</TableCell>
                                        <TableCell>{fromtime}</TableCell>
                                        <TableCell>{totime}</TableCell>
                                        <TableCell>{duration}</TableCell>                            
                                        <TableCell>
                                            <IconButton onClick={() => handleVideo(true, videourl)}>
                                                <Iconify icon={'eva:play-circle-outline'} />
                                            </IconButton>
                                        </TableCell>
                                    </TableRow>
                                )
                            })}                        
                        </TableBody>
                    </Table>
                </TableContainer>
                </>): <Box sx={{ px:2 }}>
                    <IconButton onClick={() => handleVideo(false)}>
                        <Iconify icon={'eva:arrow-back-outline'} />
                    </IconButton>
                    <Box component="video"
                    sx={{ borderRadius: 1, backgroundColor: "black", mt: 1 }}
                     width="100%"
                     src={video.url} 
                     controls
                     />
                </Box>}                
            </DialogContent>
            <DialogActions>
                <Button onClick={() => dialogHandler(false)}>Close</Button>
            </DialogActions>
        </Dialog>
    )
}