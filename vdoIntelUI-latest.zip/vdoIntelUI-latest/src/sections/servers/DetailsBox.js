import {
    Card,
    CardHeader,
    IconButton,
    CardContent,
    Stack,
    Box,
    CircularProgress,
    Typography,
    LinearProgress,
    CardActions
} from '@mui/material'
import MoreVertIcon from '@mui/icons-material/MoreVert';
import MemoryIcon from '@mui/icons-material/Memory';
import StorageIcon from '@mui/icons-material/Storage';
import OnlinePredictionIcon from '@mui/icons-material/OnlinePrediction';
import {
    circularProgressClasses,
} from '@mui/material/CircularProgress';
import Iconify from 'src/components/Iconify';
import { format } from "date-fns";



function LinearProgressWithLabel(props) {
    return (
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Box sx={{ width: '100%', mr: 1 }}>
                <LinearProgress variant="determinate" {...props} />
            </Box>
        </Box>
    );
}


function CircularProgressWithLabel(props) {
    return (
        <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="center"
            spacing={2}
            sx={{ px: 1, pt: 1 }}
        >
            <Box sx={{ position: 'relative' }}>
                <CircularProgress
                    variant="determinate"
                    sx={{
                        color: (theme) =>
                            theme.palette.grey[theme.palette.mode === 'light' ? 200 : 800],
                    }}
                    {...props}
                    value={100}
                />
                <CircularProgress
                    variant="determinate"
                    sx={{
                        color: (theme) => theme.palette[props.color].main,
                        // animationDuration: '550ms',
                        position: 'absolute',
                        left: 0,
                        [`& .${circularProgressClasses.circle}`]: {
                            strokeLinecap: 'round',
                        },
                    }}
                    {...props}
                />
                <Box
                    sx={{
                        top: 0,
                        left: 0,
                        bottom: 0,
                        right: 0,
                        position: 'absolute',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                    }}
                >
                    <Typography variant="caption" component="div" color="text.secondary">
                        {`${parseFloat(props.value).toFixed(2)}%`}
                    </Typography>
                </Box>
            </Box>
        </Stack>
    )
}


const getPercentageVal = (usedValue, value) => parseFloat(value) > 0 ? (parseFloat(usedValue)/parseFloat(value))*100 : 0

const isOnline = (lastUpdateTime) => {
    if (!lastUpdateTime) {
        return false
    }
    const today = new Date()
    const lastDateTime = new Date(lastUpdateTime)
    const diff = today - lastDateTime
    const minutes = Math.floor(Math.floor(diff / 1000) / 60);
    if (minutes <= 11)
        return true
    return false
}

const setDateTimeFormat = (lastupdate, updatedon) => lastupdate ? format(new Date(lastupdate), 'yyyy-MM-dd H:m:s') : (updatedon ? format(new Date(updatedon), 'yyyy-MM-dd H:m:s') : '')

export default function DetailsBox({ row }) {

    const { ServerIp, ServerName, Storage, RAM, Id, usedRAMgb, usedCPU, usedStorageGB, Status, LastUpdate, UpdatedOn } = row
    const RAMval = getPercentageVal(usedRAMgb, RAM)
    const storageVal = getPercentageVal(usedStorageGB, Storage)
    console.log('storageVal', storageVal)
    const islive = isOnline(LastUpdate)

    return (
        <Card
            sx={{ backgroundColor: 'rgb(244, 246, 248)' }}
        >
            <CardHeader
                title={ServerName}
                subheader={islive ? 'Online': 'Offline'}
                action={
                    <IconButton aria-label="settings">
                        <MoreVertIcon />
                    </IconButton>
                }
                avatar={<OnlinePredictionIcon color={islive ? "success" : "error"}/>}
            />
            <CardContent sx={{ p: 2 }}>                
                <Stack
                    direction="row"
                    justifyContent="space-between"
                    alignItems="center"
                    spacing={1}
                >
                    <Card sx={{ p: 2 }}>
                        <CircularProgressWithLabel size={110} thickness={6} value={parseFloat(usedCPU)} color='info' />
                        <Stack  
                        direction="row" 
                        alignItems="center" 
                        justifyContent="center" 
                        spacing={1}
                        color="gray">
                            <MemoryIcon />
                            <Typography align='center'  sx={{ fontSize: 12 }}>CPU</Typography>
                        </Stack>                            
                    </Card>
                    <Card sx={{ p: 2 }}> 
                        <CircularProgressWithLabel size={110} thickness={6} value={RAMval} color='warning' />
                        <Stack 
                        direction="row" 
                        alignItems="center" 
                        justifyContent="center" 
                        spacing={1}
                        color="gray">
                            <StorageIcon size={12}/>
                            <Typography align='center' sx={{ fontSize: 12 }}>RAM</Typography>
                        </Stack>
                    </Card>
                    
                </Stack>
               
                <Box sx={{ pt: 2 }}>
                    <Typography sx={{ fontWeight: 800 }}>Storage</Typography>
                    <Typography align='right' color="gray" sx={{ fontSize: 14, pb: 0.6, px: 1 }}>{usedStorageGB} GB of {Storage} GB Used</Typography>
                    <LinearProgressWithLabel value={storageVal} color="info" />  
                </Box>

                <Stack direction='row' sx={{ pt: 2 }}>
                    <Typography sx={{ fontWeight: 800, pr: 1 }}>Ip Address: </Typography>                  
                    <Typography>{ServerIp}</Typography>                  
                </Stack>

                <Stack direction='row' sx={{ pt: 2 }}>
                    <Typography sx={{ fontWeight: 800, pr: 1 }}>Status: </Typography>     
                    <Stack  
                    direction="row" 
                    alignItems="center" 
                    justifyContent="center" 
                    spacing={0.5}>
                        {Number(Status) === 1 ? (
                            <Iconify icon="eva:checkmark-circle-2-outline" sx={{ color: "green", fontSize: 20 }}/>
                        ): (
                            <Iconify icon="eva:close-circle-outline" sx={{ color: "red", fontSize: 20 }}/>
                        )}
                        <Typography>{Number(Status) === 1 ? 'Active': 'InActive'}</Typography>   
                    </Stack>             
                                   
                </Stack>
                
            </CardContent>
         
            <Typography sx={{ px: 3, py: 1 }} align="right" color="gray">{setDateTimeFormat(LastUpdate, UpdatedOn)}</Typography>
                 
        </Card>
    )
}