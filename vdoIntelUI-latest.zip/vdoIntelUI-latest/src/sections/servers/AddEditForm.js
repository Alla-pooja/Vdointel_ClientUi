import * as Yup from 'yup';
import { useState } from 'react';
import { useFormik, Form, FormikProvider } from 'formik';
// material
import {
  Stack,
  TextField,
  Alert,
  Box,
  Typography,
  Paper,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Autocomplete
} from '@mui/material';
import { LoadingButton } from '@mui/lab';
// component
import PropTypes from 'prop-types';
import axios from '../../axios'
import { getURL } from 'src/utils/config';
// ----------------------------------------------------------------------



export default function AddEditForm() {

  const [isError, setErrorMsg] = useState({ status: false, msg: "" })

  const [serverTypeVal, setServerType] = useState('local');

  const handleServerType = (event) => {
    setServerType(event.target.value);
  };

  const LoginSchema = Yup.object().shape({
    username: Yup.string().required('Username is required'),
    password: Yup.string().required('Password is required')
  });

  const jsonToFormData = (data) => {
    let formdata = new FormData()
    for (let x in data)
      formdata.append(x, data[x])
    return formdata
  }

  const formik = useFormik({
    initialValues: {
      username: '',
      password: '',
      grant_type: 'password'
    },
    validationSchema: LoginSchema,
    onSubmit: () => {
      setErrorMsg((er) => er.status = false)
      handleLogin(jsonToFormData(values))
    }
  });

  const handleLogin = (body, type = 'form') => {
    axios({
      method: 'post',
      url: getURL('token'),
      data: body,
      validateStatus: function (status) {
        return status >= 200 || status === 400;
      }
    }).then(function (response) {
      setSubmitting(false)
      // setUserType(localStorage.getItem('user_type'))
      // navigate('/', { replace: true })
      setErrorMsg({ status: true, msg: (response.data.error_description ?? 'The user name or password is incorrect') })
    })
  }

  const { errors, touched, values, isSubmitting, handleSubmit, getFieldProps, setSubmitting } = formik;

  return (
    <Box sx={{ p: 3, position: "relative", height: "100%", width: 350 }}>
      <Stack direction="row"
        justifyContent="space-between"
        alignItems="center"
        width="100%"
        spacing={1} sx={{ position: 'absolute', top: 0, left: 0, p: 2, backgroundColor: 'white' }}>
        <Typography variant='h5'>Add Server</Typography>
      </Stack>
      <Paper sx={{ position: 'absolute', top: 80, right: 0, width: "100%", px: 2 }}>
        <FormikProvider value={formik}>
          {(isError.status) && (
            <Alert severity="error" sx={{ mb: 3 }}>{isError.msg}</Alert>
          )}
          <Form autoComplete="off" noValidate onSubmit={handleSubmit} style={{ height: "100%" }}>
            <Stack spacing={3} sx={{ mb: 3 }}>
              <TextField
                fullWidth
                autoComplete="username"
                type="text"
                label="Server Name"
                {...getFieldProps('username')}
                error={Boolean(touched.username && errors.username)}
                helperText={touched.username && errors.username}
              />
              <TextField
                fullWidth
                autoComplete="username"
                type="text"
                label="Ip Address"
                {...getFieldProps('username')}
                error={Boolean(touched.username && errors.username)}
                helperText={touched.username && errors.username}
              />
              <TextField
                fullWidth
                autoComplete="username"
                type="text"
                label="RAM"
                {...getFieldProps('username')}
                error={Boolean(touched.username && errors.username)}
                helperText={touched.username && errors.username}
              />
              <TextField
                fullWidth
                autoComplete="username"
                type="text"
                label="Storage"
                {...getFieldProps('username')}
                error={Boolean(touched.username && errors.username)}
                helperText={touched.username && errors.username}
              />
               <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">Server Type</InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={serverTypeVal}
                    label="Server Type"
                    onChange={handleServerType}
                  >
                    <MenuItem value='live'>Live</MenuItem>
                    <MenuItem value='local'>Local</MenuItem>
                  </Select>
                </FormControl>

                {/* <Autocomplete
                  multiple
                  limitTags={2}
                  id="multiple-limit-tags"
                  options={top100Films}
                  getOptionLabel={(option) => option.title}
                  defaultValue={[top100Films[13], top100Films[12], top100Films[11]]}
                  renderInput={(params) => (
                    <TextField {...params} label="limitTags" placeholder="Favorites" />
                  )}
                  sx={{ width: '500px' }}
                /> */}

            </Stack>
            {/* <LoadingButton
          fullWidth
          size="large"
          type="submit"
          variant="contained"
          loading={isSubmitting}
        >
          Login
        </LoadingButton> */}
          </Form>
        </FormikProvider>
      </Paper>
      <Stack direction="row"
        justifyContent="space-between"
        alignItems="center"
        spacing={1}
        width="100%"
        sx={{ position: 'absolute', bottom: 0, right: 0, p: 2 }}>
        <Button variant='contained' color='error' fullWidth>Cancel</Button>
        <Button variant='contained' fullWidth>Save</Button>
      </Stack>
    </Box>
  );
}