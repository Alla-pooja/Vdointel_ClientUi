import PropTypes from 'prop-types';
// import { Link as RouterLink } from 'react-router-dom';
// material
import { Box, Card, Stack, Chip, Avatar } from '@mui/material';
import { styled } from '@mui/material/styles';
// utils
// import { fCurrency } from '../../utils/formatNumber';
// components
import Label from '../../components/Label';
// import { ColorPreview } from '../../components/color-utils';
import Iconify from 'src/components/Iconify';
import { green } from '@mui/material/colors';
// ----------------------------------------------------------------------
const ProductImgStyle = styled('img')({
  top: 0,
  width: '100%',
  height: '100%',
  objectFit: 'cover',
  position: 'absolute',
});
// ----------------------------------------------------------------------

AuditListCard.propTypes = {
  audit: PropTypes.object,
};

export default function AuditListCard({ audit, handleDialog }) {
  const { EventNo, CameraId, ClientCreatedOn, DetectedType, devicename, SnapshotUrl } = audit;
  const snapurl = SnapshotUrl !== null ? SnapshotUrl : `https://vdointel.online/vdointel/deviceimages/${CameraId}.jpg`
  return (
    <Card onClick={() => handleDialog(audit)}>

      
      <Box sx={{ minHeight: 200, position: 'relative', background: 'linear-gradient(to top, rgb(6, 6, 6), 20%, rgb(51 51 51))' }}>
        
      {ClientCreatedOn && (
          <Label
            variant="filled"
            color={'info'}
            sx={{
              zIndex: 9,
              top: 16,
              right: 16,
              position: 'absolute',
              textTransform: 'uppercase',
            }}
          >{ClientCreatedOn}</Label>
        )}
      <Label
          variant="filled"
          color='secondary'
          sx={{
            zIndex: 9,
            top: 42,
            right: 16,
            position: 'absolute',
            textTransform: 'uppercase',
          }}
        >
          Audit Id {EventNo}
        </Label>
        
        <Label
          variant="filled"
          color='secondary'
          sx={{
            zIndex: 9,
            top: 68,
            right: 16,
            position: 'absolute',
            textTransform: 'uppercase',
          }}
        >
          {devicename}
        </Label>
        <Avatar
          sx={{
            zIndex: 9,
            top: '45%',
            left: '45%',
            position: 'absolute',
            textTransform: 'uppercase',
            bgcolor: green[500]
          }}
        >
          <Iconify icon="eva:play-circle-outline" width={30} height={30} />
        </Avatar>
        {snapurl && (
          <ProductImgStyle alt={ClientCreatedOn} src={snapurl} />
        )}
      </Box>
      <Stack direction="row" spacing={1} sx={{ m: 2 }}>
        {(DetectedType) && [...DetectedType.split(',')].map((value, key) => (
          <Chip sx={{ textTransform: "capitalize" }} key={key} avatar={<Avatar>{value.charAt(0).toUpperCase() || ''}</Avatar>} label={value} />
        ))}
      </Stack>    
    </Card>
  );
}
