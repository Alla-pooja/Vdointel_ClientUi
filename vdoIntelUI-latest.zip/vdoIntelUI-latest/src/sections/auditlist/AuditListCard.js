import PropTypes from 'prop-types';
// import { Link as RouterLink } from 'react-router-dom';
// material
import { Box, Card, Stack, Chip, Avatar, Typography, Button } from '@mui/material';
import { styled } from '@mui/material/styles';
// utils
// import { fCurrency } from '../../utils/formatNumber';
// components
import Label from '../../components/Label';
// import { ColorPreview } from '../../components/color-utils';
import Iconify from 'src/components/Iconify';
import { green } from '@mui/material/colors';
import { LoadingButton } from '@mui/lab';
import { useState } from 'react';
import { handleResponse } from "src/utils/responseHandler"
import axios from 'src/axios'
import { getURL } from 'src/utils/config';
// ----------------------------------------------------------------------
const ProductImgStyle = styled('img')({
  top: 0,
  width: '100%',
  height: '100%',
  objectFit: 'cover',
  position: 'absolute',
});
// ----------------------------------------------------------------------

AuditListCard.propTypes = {
  audit: PropTypes.object,
};

export default function AuditListCard({ audit, handleDialog }) {
  // const [isSubmitting, setIsSubmitting] = useState(false)
  const { EventNo, CameraId, ClientCreatedOn, DetectedType, devicename, SnapshotUrl, VideoUrl } = audit;
  const snapurl = SnapshotUrl !== null ? SnapshotUrl : `https://vdointel.online/vdointel/deviceimages/${CameraId}.jpg`

  // const sendMail = () => {
  //   setIsSubmitting(true)
  //     axios({
  //       method: 'get',
  //       url: getURL(`client-info/send-client-mail-consolidated?devicename=${devicename}&detectedtype=${DetectedType}&videourl=${VideoUrl}`),
  //       validateStatus: (status) => handleResponse(status),
  //   }).then(function (response) {
  //       setIsSubmitting(false)
  //       if (response.status === 200) {
  //         window.alert("Email has been sent successfully.")
  //       } else {
  //         window.alert("Something went wrong. Please try again later")
  //       }
  //   })
  // }



  return (
    <Card sx={{ p: 1}}>

      <Card>

      <Box onClick={() => handleDialog(audit)} sx={{ minHeight: 200, position: 'relative', background: 'linear-gradient(to top, rgb(6, 6, 6), 20%, rgb(51 51 51))', cursor: "pointer" }}>
        
        {/* {ClientCreatedOn && (
            <Label
              variant="filled"
              color={'info'}
              sx={{
                zIndex: 9,
                top: 16,
                right: 16,
                position: 'absolute',
                textTransform: 'uppercase',
              }}
            >{ClientCreatedOn}</Label>
          )}
        <Label
            variant="filled"
            color='secondary'
            sx={{
              zIndex: 9,
              top: 42,
              right: 16,
              position: 'absolute',
              textTransform: 'uppercase',
            }}
          >
            Audit Id {EventNo}
          </Label>
          
          <Label
            variant="filled"
            color='secondary'
            sx={{
              zIndex: 9,
              top: 68,
              right: 16,
              position: 'absolute',
              textTransform: 'uppercase',
            }}
          >
            {devicename}
          </Label> */}
          <Avatar
            sx={{
              zIndex: 9,
              top: '45%',
              left: '45%',
              position: 'absolute',
              textTransform: 'uppercase',
              bgcolor: green[500]
            }}
          >
            <Iconify icon="eva:play-circle-outline" width={30} height={30} />
          </Avatar>
          {snapurl && (
            <ProductImgStyle alt={ClientCreatedOn} src={snapurl} />
          )}
        </Box>

      </Card>
      <Box sx={{p: 2}}>
        <Typography color="gray" sx={{fontSize: "0.75rem"}}>{ClientCreatedOn}</Typography>
        <Typography variant='h6' sx={{ fontSize: "1rem", textTransform: "capitalize" }}>{DetectedType}</Typography>
        <Stack direction="row"
          justifyContent="flex-start"
          alignItems="center"
          spacing={1}
          sx={{pt: 1}}
          
          >
          <Typography sx={{ fontSize: "0.9rem", fontWeight: 800 }}>Camera: </Typography>
          <Typography sx={{ fontSize: "0.9rem", textTransform: "capitalize" }}>{devicename}</Typography>
        </Stack>
        <Stack direction="row"
          justifyContent="flex-start"
          alignItems="center"
          spacing={1}
          
          >
          <Typography  sx={{ fontSize: "0.9rem", fontWeight: 800 }}>Audit ID: </Typography>
          <Typography sx={{ fontSize: "0.9rem" }}>{EventNo}</Typography>
          
        </Stack>
        {/* {Number(localStorage.getItem("client_id")) === 831 && (
          <LoadingButton 
          sx={{ mt: 2}}
          fullWidth
          variant="contained"
          loading={isSubmitting}
          onClick={sendMail}
          >
          Send Mail
          </LoadingButton>
        )}         */}
      </Box>
      
      
      
      {/* <Stack direction="row" spacing={1} sx={{ m: 2 }}>
        {(DetectedType) && [...DetectedType.split(',')].map((value, key) => (
          <Chip sx={{ textTransform: "capitalize" }} key={key} avatar={<Avatar>{value.charAt(0).toUpperCase() || ''}</Avatar>} label={value} />
        ))}
      </Stack>     */}
    </Card>
  );
}
