import PropTypes from 'prop-types';
import {   
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    Switch,
    FormGroup,
    FormControlLabel,
    Snackbar,
    Alert
  } from '@mui/material'
import { useEffect, useState } from 'react';

const SwitchLabels = ({ subAnalytics, activeCameras, checkAnalytics, setSnackbar, setActiveAnalytics }) => {    
    const { Id, Name, DisplayName, AnalyticId, isActive } = subAnalytics
    // console.log(subAnalytics)
    const handleSwitchBar = (_, value) => {   
        // console.log(activeCameras.length)
        setSnackbar(activeCameras.length === 0 && value)
        // console.log(AnalyticId, Id)
        if (activeCameras.length) {
            // console.log('Allow', value)
            setActiveAnalytics(activeCameras, AnalyticId, Id, value)
        }
    }
    return (
        // <FormControlLabel control={<Switch defaultChecked color="success" />} label={Name} />        
        <FormControlLabel control={<Switch color="success" checked={isActive===1} onChange={handleSwitchBar} />} label={DisplayName} />
    );
}

export default function SubAnalyticsDialogBox({ analyticsSub, main, handleClose, checkAnalytics, setActiveAnalytics }) {
    // console.log(main)

    const [ isOpen, setSnackbar ] = useState(false)

    useEffect(() => {
        if (isOpen)
            setSnackbar(false)
    }, [main.open])

    return (
        <Dialog
            open={main.open}
            onClose={handleClose}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
        >
            <DialogTitle id="alert-dialog-title">
                {main.AnalyticName}
            </DialogTitle>
            <DialogContent>
                {/* <DialogContentText id="alert-dialog-description"> */}
                    <FormGroup>
                        {(main.activeMainId in analyticsSub.data) && Object.values(analyticsSub.data[main.activeMainId]).map((row, key) => (
                            <SwitchLabels key={key} subAnalytics={row} activeCameras={main.activeCamIds} checkAnalytics={checkAnalytics} setSnackbar={setSnackbar} setActiveAnalytics={setActiveAnalytics}/>
                        ))}
                    </FormGroup>
                {/* </DialogContentText> */}
            </DialogContent>
            <DialogActions>
                <Button onClick={handleClose} autoFocus>Done</Button>
            </DialogActions>    
           
            <Snackbar open={isOpen} autoHideDuration={3000} >
                <Alert severity="error" sx={{ width: "100%" }}>Please select camera atleast one!</Alert>
            </Snackbar>


        </Dialog>
    );
}

SubAnalyticsDialogBox.propTypes = {
    main: PropTypes.object.isRequired,
    handleClose: PropTypes.func.isRequired
}