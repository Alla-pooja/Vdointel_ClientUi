## Getting started

- Recommended `node js 14.x` and `npm 6+`. (suggestion v14.17.3 / v16.15.0)
- Install dependencies: `npm install` / `yarn install`
- Start the project: `npm run start` / `yarn start`

